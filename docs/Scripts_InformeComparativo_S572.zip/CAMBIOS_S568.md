# CAMBIOS S568 — Informe Comparativo
- Auditoría de alineación: el informe ahora usa exactamente los 1.656 registros vigentes del corpus (misma regla `vigente()` que los exports).
  - Antes incluía 9 registros ANULADOS (no imputables: MAI-2014-30, MAI-2016-05/90, MAI-2019-93/99, MAI-2020-93, CAI-2019-90, MAI-2021-90, MAI-2022-90) y excluía 2 vigentes (FAI-1995-42, FAI-1999-M39) porque su nota mencionaba la palabra «superseded».
  - Efecto: I-18 r 0,988→0,999; I-23 r 0,249→0,260. Calificaciones sin cambio: 18 EXC · 9 BUENO · 3 ACEPT · 2 PARCIAL · 4 DIVERG.
- Conteo de registros en portada y pies ahora calculado (antes fijo en 1,657).
