# Cambios S572 (19-nov-2026)
- Corpus S572: sesgo principal recodificado con reglas v2 (mecanismo documentado antes que escenario). Ningún elemento del informe usa el sesgo principal: los 36 elementos quedan idénticos a S570/S571.
- Calificaciones: 17 EXCELENTE · 10 BUENO · 3 ACEPTABLE · 2 PARCIAL · 4 DIVERGENCIA DOC.
