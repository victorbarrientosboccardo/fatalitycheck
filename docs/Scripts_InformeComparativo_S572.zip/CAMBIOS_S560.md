# CAMBIOS S560 — Informe Comparativo
- Corpus: ingesta de los 260 registros de 1997-1999 desde el texto completo de los informes oficiales MSHA (256 informes). FAI-1999-M39 se restituye (2.ª víctima de FTL99M38) y MAI-1999-90 se retira (duplicado de FAI-1999-M55). Vigentes: 1.656.
- Mina / empresa normalizada en 1995-1999: el contratista se menciona solo si la víctima era empleada de un contratista.
- Universo truck 1995-2002: +2 casos (FAI-1998-M43 COLL/WARN, FAI-1999-M34 ROLL/MAINT).
- Calificaciones: 19 EXC · 8 BUENO · 2 ACEPT · 3 PARCIAL · 4 DIVERG (antes 21·5·4·2·4).
  - I-14 EXCELENTE→BUENO (r 0,958→0,906): equipos por año reclasificados con ocupaciones reales.
  - I-24 EXCELENTE→BUENO (r 0,952→0,939): demografía por tipo de empleo.
  - I-26 ACEPTABLE→PARCIAL (r 0,816→0,535): búsqueda por palabras clave en texto, ahora más largo y real; además 1998-1999 tienen más contratistas que los años 2000-2007 aún no ingeridos.
  - I-31 ACEPTABLE→BUENO (r 0,823→0,864): causas raíz de cargadores ya reales.
- Estos cambios reflejan datos corregidos y una ingesta desigual por año. Hay que reevaluarlos cuando se ingieran 2000-2007, y conviene redefinir I-26 sobre campos estructurados (actividad, contratista) en vez de buscar palabras clave en el texto.
