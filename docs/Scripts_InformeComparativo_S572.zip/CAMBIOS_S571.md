# Cambios S571 (19-nov-2026)
- Corpus S571: sesgo principal recodificado con reglas de desempate en 1.327 registros (773 cambian). Ningún elemento del informe usa el sesgo principal: los 36 elementos quedan idénticos a S570.
- Calificaciones: 17 EXCELENTE · 10 BUENO · 3 ACEPTABLE · 2 PARCIAL · 4 DIVERGENCIA DOC.
