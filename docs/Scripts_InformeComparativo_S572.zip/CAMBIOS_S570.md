# Cambios S570 (19-nov-2026)
- Corpus S570: equipo (BG) reescrito desde el informe con vocabulario controlado de 35 categorías; lib.py usa la tabla _VOC570 (BG manda; ya no cae a Part 50 cuando BG es una categoría controlada).
- Cambian 13 de 36 elementos (los que usan equipo, hora o tipo): I-02, I-03, I-04, I-06, I-07, I-08, I-19, I-22, I-23, I-25, I-30, I-35, I-36.
- Calificaciones: 17 EXCELENTE · 10 BUENO · 3 ACEPTABLE · 2 PARCIAL · 4 DIVERGENCIA DOC. (I-36 baja de EXCELENTE a BUENO: r 0,975 → 0,879).
- El universo de camiones (I-12/13/14) no cambió: el assert pasó sin recodificar.
