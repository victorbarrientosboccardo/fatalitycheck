import sys, json
sys.path.insert(0, sys.argv[1])
from lib import *
from items import ITEMS
out={}
for it in ITEMS:
    pf,T,interp,note=it['builder']()
    T=aplicar_divergencia(it['code'],T)
    out[it['code']]={k:(round(v,4) if isinstance(v,float) else v) for k,v in T.items() if isinstance(v,(int,float,str)) and k in ('qual','r','delta','mape','sump','sumc','rho','ccc','n')}
json.dump(out,open(sys.argv[2],'w'),ensure_ascii=False,indent=0)
print(len(out),"items; claves:",list(next(iter(out.values())).keys()))
