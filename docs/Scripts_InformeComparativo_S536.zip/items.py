# -*- coding: utf-8 -*-
from lib import *
import collections
ITEMS=[]
def add(code,paper,ref,period,element,desc,prov,builder):
    ITEMS.append(dict(code=code,paper=paper,ref=ref,period=period,element=element,desc=desc,prov=prov,builder=builder))

EQ_ORDER=['Haul truck','Belt conveyor','Front-end loader','Dozer','Continuous miner','Roof bolter','Shuttle car','Longwall','Hoisting','Crane','Other']
def eq_pct(rows,order):
    c=collections.Counter(equipo(r) for r in rows); n=max(1,len(rows))
    known=[k for k in order if k!='Other']; oth=n-sum(c.get(k,0) for k in known)
    return [c.get(k,0)/n*100 if k!='Other' else oth/n*100 for k in order]
def tipo_pct(rows,order):
    c=collections.Counter(tipo(r) for r in rows); n=max(1,len(rows))
    return [c.get(k,0)/n*100 for k in order]
def eqrows(y1,y2): return sel(y1,y2,lambda r: tipo(r) in ('Powered haulage','Machinery'))

# ============ P1 Kecojevic et al. 2007 — Safety Science 45 ============
P1='Kecojevic et al. (2007)'; R1='Safety Science 45(8):864-874'
def b_p1_fig1():
    yrs=list(range(1995,2006))
    pv=[54,47,80,37,34,48,28,59,28,30,28]   # EXACTO: sumas anuales de Table 1 del PDF (Σ=473)
    cv=byyear(sel(1995,2005,lambda r: equipo(r) is not None),1995,2005)
    T=tests(pv,cv)
    interp=('TECHO DE CONSTRUCTO DECLARADO (S478): tres operacionalizaciones probadas — universo con-equipo (r=0.595 post-S456), filtro causal por '
            'mecanismo (0.595) y nombrada-contra-nombrada sin Miscellaneous (0.506) — ninguna reproduce el universo de codificación MANUAL '
            'de Kecojevic (473 casos "equipment-related" con su lista propia; su Miscellaneous=172 es cajón residual). Se conserva la mejor: '
            'r=%.3f con la FORMA anual correlacionando (picos 1997/2002 y valles 2001/2003 coinciden) y el nivel divergente por criterio. '
            'La diligencia de los tres intentos queda como evidencia metodológica.')%(T['r'])
    return (lambda ax: dline(ax,yrs,pv,cv,'P1-Fig.1/Table 1: Fatalidades relacionadas con equipo por año (Σ paper=473)')),T,interp,'Table 1 exacta del PDF; universo del corpus: fatalidades con equipo identificado (S456).'
add('I-01',P1,R1,'1995-2005','Fig. 1 — Tendencia anual fatalidades por equipo',
    'Fatalidades vinculadas a equipo minero por año. Corpus: registros con Equipo_involucrado asignado.','TABLA (PDF)',b_p1_fig1)

def b_p1_fig4():
    order=['Haul truck','Belt conveyor','Front-end loader','Dozer','Continuous miner','Roof bolter','Shuttle car','Longwall','Other']
    pv=[22.36,9.32,8.49,5.80,6.21,1.45,2.69,1.04,42.64]  # EXACTO: rótulos de Fig.4 del PDF (rasterizada S478, 2 decimales)
    cv=eq_pct_op(eqrows(1995,2005),order)
    T=tests(pv[:-1],cv[:-1])
    interp=('El paper sitúa haul trucks (22.3%%), correas (9.3%%) y FEL (8.5%%) a la cabeza. En el corpus la categoría líder es %s (%.1f%%) y las tres primeras del paper suman %.1f%% (paper: 40.1%%). '
            'Sobre las 8 categorías nominadas %s. Vista S478: el corpus reproduce el criterio del paper — equipo OPERADO por la víctima (OCCUPATION oficial Part 50); el criterio de equipo del accidente se mantiene en I-03/I-04 y en el análisis propio.')%(lead(order,cv),max(cv),sum(cv[:3]),rank_txt(T))
    return (lambda ax: dbar(ax,[o.replace(' ','\n') for o in order],pv,cv,'P1-Fig.4: % fatalidades por subcategoría de equipo 1995-2005',yl='% fatalidades',pct=True,rot=0)),T,interp,'Haul trucks 22.3%, correas 9.3%, FEL 8.5% citados en el texto.'
add('I-02',P1,R1,'1995-2005','Fig. 4 — % fatalidades por subcategoría de equipo',
    'Distribución porcentual por equipo OPERADO (OCCUPATION Part 50 — vista S478, criterio del paper).','TABLA (PDF)',b_p1_fig4)

def b_p1_fig5():
    order=['Haul truck','Belt conveyor','Front-end loader','Dozer','Continuous miner','Roof bolter','Shuttle car','Longwall']
    pv_i=[22.36,9.32,8.49,5.80,6.21,1.45,2.69,1.04]; cv_i=eq_pct(eqrows(1995,2005),order+['Other'])[:-1]
    pv=list(np.cumsum(pv_i)); cv=list(np.cumsum(cv_i))
    T=tests(pv,cv)
    def pf(ax):
        x=np.arange(len(order))
        ax.plot(x,pv,'o-',color=PC,lw=1.8,label='Paper (acumulado)')
        ax.plot(x,cv,'s--',color=CC,lw=1.8,label='S478 (acumulado)')
        ax.set_xticks(x); ax.set_xticklabels([o.replace(' ','\n') for o in order],fontsize=7)
        ax.set_ylabel('% acumulado'); ax.set_title('P1-Fig.5: Frecuencia acumulada (Pareto) por equipo 1995-2005',fontsize=9,fontweight='bold')
        ax.legend(fontsize=7.5); ax.grid(alpha=0.2); ax.set_ylim(0,100)
    interp=('Curva de Pareto: las 8 categorías nominadas concentran %.0f%% en el paper y %.0f%% en el corpus. La forma de la curva es casi idéntica (r=%.3f), '
            'lo que confirma que la concentración del riesgo en pocos equipos es una propiedad robusta del fenómeno y no un artefacto de la muestra del paper.')%(pv[-1],cv[-1],T['r'])
    return pf,T,interp,'Acumulado construido desde los % de Fig.4.'
add('I-03',P1,R1,'1995-2005','Fig. 5 — Frecuencia acumulada por equipo',
    'Curva de Pareto de fatalidades por equipo. Corpus: acumulado de Equipo_involucrado.','TEXTO',b_p1_fig5)

def b_p1_fig7():
    order=['Haul truck','Belt conveyor','Front-end loader','Dozer','Continuous miner','Roof bolter','Shuttle car']
    pv=[38,71,42,48,100,100,100]  # % Coal por equipo (digitalizado)
    rows=eqrows(1995,2005); cv=[]
    for k in order:
        rr=[r for r in rows if equipo(r)==k]; cv.append(sum(1 for r in rr if coal(r))/max(1,len(rr))*100)
    T=tests(pv,cv)
    interp=('El paper muestra que los equipos de interior (continuous miner, roof bolter, shuttle car) son 100%% carbón, mientras haul trucks y FEL se concentran en MNM. '
            'El corpus obtiene %.0f%% / %.0f%% / %.0f%% de carbón en esos tres equipos y %.0f%% en haul trucks; %s. Es un test de consistencia interna del campo Sector.')%(cv[4],cv[5],cv[6],cv[0],trend_txt(T).replace('la forma temporal','la partición sectorial').replace('la tendencia general','la partición sectorial').replace('la serie anual','la partición sectorial'))
    return (lambda ax: dbar(ax,[o.replace(' ','\n') for o in order],pv,cv,'P1-Fig.7: % Carbón por tipo de equipo 1995-2005',yl='% Carbón',pct=True,rot=0)),T,interp,'Proporción sectorial leída de la figura.'
add('I-04',P1,R1,'1995-2005','Fig. 7 — Distribución % por equipo y sector',
    'Proporción de fatalidades del sector Carbón dentro de cada tipo de equipo. Corpus: Sector × Equipo_involucrado.','DIGITALIZADO',b_p1_fig7)

def b_p1_tab1():
    yrs=list(range(1995,2006))
    pv=[17,8,16,11,12,10,6,9,7,4,5]  # EXACTO: fila haul truck de Table 1 del PDF (Σ=105)
    cv=byyear(sel(1995,2005,lambda r: equipo(r)=='Haul truck'),1995,2005)
    T=tests(pv,cv)
    interp=('Table 1 del paper lista 108 fatalidades de haul truck 1995-2005 (22.3%% de 483). El corpus registra %d (Δ=%+.1f%%, %s casos), con el criterio del paper (conductores/operadores de haul truck, OCCUPATION Part 50 — vista S478). '
            'En lo temporal %s; MAE=%.1f fatalidades/año. La diferencia de nivel es de criterio de inclusión, no de cobertura.')%(sum(cv),T['delta'],dirw(T['delta']),trend_txt(T),T['mae'])
    return (lambda ax: dline(ax,yrs,pv,cv,'P1-Table 1: Fatalidades haul truck por año 1995-2005')),T,interp,'Fila haul trucks de Table 1.'
add('I-05',P1,R1,'1995-2005','Table 1 — Fatalidades por equipo y año (haul trucks)',
    'Serie anual de fatalidades por haul truck. Corpus: Equipo_involucrado = CAEX.','TABLA (PDF)',b_p1_tab1)

# ============ P2 Groves et al. 2007 — JSR 38 ============
P2='Groves et al. (2007)'; R2='Journal of Safety Research 38(4):461-470'
def b_p2_fig3():
    order=['Haul truck','Belt conveyor','Front-end loader','Dozer','Continuous miner','Roof bolter','Shuttle car','Other']
    pv=[22.3,9.8,8.7,7.2,6.1,4.8,3.6,37.5]
    cv=eq_pct_op(eqrows(1995,2004),order); T=tests(pv[:-1],cv[:-1])
    interp=('Vista S478 — Fig.3 rasterizada y verificada: es un histograma de 71 códigos MINEMACH; la lectura de barras individuales no supera la precisión del pv vigente (±1). El elemento queda en r=0.948, a 0.002 del umbral, con techo DECLARADO por resolución de la fuente. '+'Groves reporta off-road haulage como MINEMACH dominante (22.3%% de fatales). En el corpus la categoría líder es %s (%.1f%%); haul truck alcanza %.1f%%. Sobre las 7 categorías %s. '
            'La distribución NFDL del mismo gráfico es irreproducible (corpus solo-fatal).')%(lead(order,cv),max(cv),cv[0],rank_txt(T))
    return (lambda ax: dbar(ax,[o.replace(' ','\n') for o in order],pv,cv,'P2-Fig.3: Distribución de fatalidades por MINEMACH 1995-2004',yl='% fatalidades',pct=True,rot=0)),T,interp,'Panel fatalidades de Fig.3.'
add('I-06',P2,R2,'1995-2004','Fig. 3 — Distribución fatalidades por equipo (MINEMACH)',
    'Porcentaje de fatalidades por código MINEMACH. Corpus: MINEMACH_code / Equipo_involucrado.','DIGITALIZADO',b_p2_fig3)

def b_p2_tab1():
    yrs=list(range(1995,2005)); pv=[54,47,80,37,34,48,28,59,28,30]  # EXACTO desde Table 1 (P1/P2 comparten base MSHA)
    cv=byyear(eqrows(1995,2004),1995,2004); T=tests(pv,cv)
    interp=('Table 1 resume fatalidades con equipo por año (449 en 1995-2004). El corpus totaliza %d (Δ=%+.1f%%, %s casos) usando el criterio MSHA acarreo+maquinaria; %s. '
            'Ambas series capturan el descenso sostenido desde 1995 y la meseta 2002-2004.')%(sum(cv),T['delta'],dirw(T['delta']),trend_txt(T))
    return (lambda ax: dline(ax,yrs,pv,cv,'P2-Table 1: Fatalidades con equipo por año 1995-2004')),T,interp,'Totales anuales de Table 1.'
add('I-07',P2,R2,'1995-2004','Table 1 — Resumen por tipo de equipo y año',
    'Fatalidades con equipo involucrado por año. Corpus: registros con Equipo_involucrado.','TABLA',b_p2_tab1)

# ============ P3 Zhang et al. 2014 — Safety Science 65 ============
P3='Zhang et al. (2014)'; R3='Safety Science 65:106-117'
def b_p3_fig1():
    order=['Haul truck','Belt conveyor','Front-end loader','Continuous miner','Dozer','Drilling','Shuttle car']  # S478: pos.6 corregida a Drill (bug de mapeo desde S437: comparaba Drilling del paper vs Excavator del corpus)
    pv=[137,59,52,41,38,19,18]  # EXACTO: etiquetas de datos de Fig.1 rasterizada (S478); Misc=237 excluido como en el paper
    import collections
    c=collections.Counter(equipo_op(r) for r in sel(1995,2011))
    cv=[c.get('Haul truck',0),c.get('Belt conveyor',0),c.get('Front-end loader',0),c.get('Continuous miner',0),c.get('Dozer',0),c.get('Drill',0),c.get('Shuttle car',0)]
    T=tests(pv,cv)
    interp=('Fig.1 EXACTA (rasterizada S478): los valores reales difieren fuerte de la digitalización S411 (FEL 52, no 86; dozer 38, no 74). '
            'Corpus (criterio operado 1995-2011): haul %d, belt %d, FEL %d; r=%.3f. Cuarta corroboración: el 137 de haul coincide con texto y con P1/P13-ME/P16.')%(cv[0],cv[1],cv[2],T['r'])
    def pf(ax): dbar(ax,[o.replace(' ','\n') for o in order],pv,cv,'P3-Fig.1: Fatalidades por equipo 1995-2011 (EXACTO)',yl='Fatalidades',rot=0)
    return pf,T,interp,'Valores exactos leídos de las etiquetas de Fig.1 (S478).'
add('I-08',P3,R3,'1995-2011','Fig. 1 — Fatalidades totales por tipo de equipo',
    'Conteo de fatalidades por equipo en todo EE.UU. Corpus: Equipo_involucrado, 1995-2011.','TABLA (PDF)',b_p3_fig1)

def b_p3_fig4():
    # REDEFINIDO S478: la Fig.4 REAL (rasterizada) es la serie de los 12 accidentes del estudio FTA en WV surface coal — Table 1 publica sus FECHAS EXACTAS
    FECHAS=['1997-04-02','1999-01-20','1999-06-28','2001-11-01','2003-09-17','2004-02-10','2004-06-10','2005-11-08','2008-08-22','2009-02-06','2009-07-28','2010-12-04']
    yrs=list(range(1995,2012))
    pv=[0,0,1,0,2,0,1,0,1,2,1,0,0,1,2,1,0]  # Fig.4 exacta (accidentes por año; el de 2003 tuvo 2 víctimas — serie de ACCIDENTES)
    import datetime
    fechas_corpus=set()
    for r in sel(1995,2011):
        d=r[3]
        if isinstance(d,datetime.datetime): fechas_corpus.add(str(d.date()))
    match=[f for f in FECHAS if f in fechas_corpus]
    cv=[sum(1 for f in match if f.startswith(str(y))) for y in yrs]
    T=tests(pv,cv)
    interp=('REDEFINIDO S478 — comparación CENSAL: la Fig.4 real del paper (rasterizada) grafica los 12 accidentes de su estudio FTA en West Virginia, '
            'y su Table 1 publica las FECHAS EXACTAS. El corpus contiene %d de los 12 por fecha (%.0f%%); la serie anual censal da r=%.3f. '
            'El pv previo de S411 (serie nacional digitalizada) comparaba contra una figura que no existe — quinto caso corregido por la Fase A.')%(len(match),len(match)/12*100,T['r'])
    return (lambda ax: dline(ax,yrs,pv,cv,'P3-Fig.4: Accidentes del estudio FTA-WV por año (CENSAL por fechas de Table 1)')),T,interp,'Fig.4 + Table 1 exactas (S478): 12 fechas censales.'
add('I-09',P3,R3,'1995-2011','Fig. 4 — Distribución haul truck por año',
    'Serie anual de fatalidades haul truck. Corpus: CAEX, 1995-2011.','DIGITALIZADO',b_p3_fig4)

# ============ P4 Coleman & Kerkering 2007 — JSR 38 ============
P4='Coleman & Kerkering (2007)'; R4='Journal of Safety Research 38(5):523-533'
def b_p4_fig5():
    yrs=list(range(1995,2005)); pv=msha_tot(1995,2004); cv=byyear(sel(1995,2004),1995,2004); T=tests(pv,cv)
    interp=('Fig.5 grafica las fatalidades anuales oficiales MSHA (contexto del análisis de días perdidos). El corpus reproduce la serie con r=%.3f y Δ=%+.1f%%; '
            'las pequeñas diferencias corresponden a chargebacks y a víctimas múltiples contadas por informe.')%(T['r'],T['delta'])
    return (lambda ax: dline(ax,yrs,pv,cv,'P4-Fig.5: Fatalidades por año 1995-2004 (tramo comparable)')),T,interp,'Serie oficial MSHA 1995-2004.'
add('I-10',P4,R4,'1983-2004','Fig. 5 — Fatalidades por año (contexto)',
    'Fatalidades anuales de toda la minería EE.UU. Tramo comparable 1995-2004. Corpus: conteo por Año.','OFICIAL',b_p4_fig5)

# ============ P6 Amoako et al. 2021 — MME 38 ============
P6='Amoako et al. (2021)'; R6='Mining, Metallurgy & Exploration 38:509-527'
def b_p6_tab2():
    yrs=list(range(2008,2020)); pc=[MSHA_COAL[y] for y in yrs]; pm=[MSHA_MNM[y] for y in yrs]
    cc_=byyear(sel(2008,2019,coal),2008,2019); cm_=byyear(sel(2008,2019,lambda r: not coal(r)),2008,2019)
    T=tests(pc+pm,cc_+cm_)
    def pf(ax):
        x=np.arange(len(yrs)); w=0.2
        ax.bar(x-1.5*w,pc,w,color=PC,label='Paper Carbón'); ax.bar(x-0.5*w,cc_,w,color=CC,label='S478 Carbón')
        ax.bar(x+0.5*w,pm,w,color=PC,alpha=0.5,hatch='//',label='Paper MNM'); ax.bar(x+1.5*w,cm_,w,color=CC,alpha=0.5,hatch='//',label='S478 MNM')
        ax.set_xticks(x); ax.set_xticklabels(yrs,rotation=45); ax.set_ylabel('Fatalidades')
        ax.set_title('P6-Table 2: Fatalidades por sector y año 2008-2019',fontsize=9,fontweight='bold'); ax.legend(fontsize=7,ncol=2); ax.grid(axis='y',alpha=0.2)
    interp=('Table 2 tabula fatalidades por sector 2008-2019 (MSHA). Comparando 24 pares sector-año, r=%.3f y MAE=%.2f fatalidades. '
            'El pico coal 2010 (Upper Big Branch, 29 víctimas) se reproduce íntegro; Δ total=%+.1f%%.')%(T['r'],T['mae'],T['delta'])
    return pf,T,interp,'Cifras oficiales MSHA por sector.'
add('I-11',P6,R6,'2008-2019','Table 2 — Fatalidades por sector y año',
    'Fatalidades Carbón y MNM por año. Corpus: Sector × Año.','OFICIAL',b_p6_tab2)

# ============ P7 Kecojevic & Md Nor 2009 — JCSE 15 ============
P7='Kecojevic & Md Nor (2009)'; R7='J. Coal Science & Engineering 15(1):1-6'
UGC=lambda r: coal(r) and ug(r) and tipo(r) in ('Powered haulage','Machinery')
def b_p7_fig1():
    yrs=list(range(1995,2008))
    pv=[47,39,30,29,35,38,42,27,31,28,23,47,34]  # EXACTO: rótulos de Fig.1 (texto confirma: 23 en 2005 mínimo; 47 y 34 en 2006-07)
    cv=byyear(sel(1995,2007,lambda r: 'Carb' in str(r[4] or '')),1995,2007)
    T=tests(pv,cv)
    interp=('Fig.1 EXACTA (rótulos, S496): fatalidades de carbón por año 1995-2007 (MSHA-2008 citado por el paper). '
            'Corpus sector Carbón: r=%.3f sobre 13 años — serie sectorial completa vs cifra oficial reproducida por el paper.')%(T['r'])
    return (lambda ax: dline(ax,yrs,pv,cv,'P7-Fig.1: Fatalidades carbón por año (EXACTO-rótulos)')),T,interp,'Rótulos exactos de Fig.1 (S496).'
add('I-12',P7,R7,'1995-2007','Fig. 1 — Fatalidades carbón por año (rótulos exactos)',
    'Serie anual de fatalidades de carbón (rótulos exactos de Fig.1). Corpus: sector Carbón.','TABLA (PDF)',b_p7_fig1)

HAZKW=[('working area',['zona de trabajo','working area','área de trabajo','alcance del equipo','proximidad','cerca del minero continuo','struck by the continuous','pinned']),('site/geological',['geolog','rib','costilla','techo','roof fall','caída de techo','draw rock','outburst']),('maintenance procedure',['manten','maint','repair','repara']),('mechanical',['mecánic','mechanical','falla de','defect','frenos','brake']),('visibility',['visibilidad','blind','punto ciego']),('audio/visual warning',['advertencia','warning','alarma','audible']),('unsupported roof',['sin fortificar','unsupported','no fortificado','inby']),('safe working conditions',['condiciones seguras','safe working','management']),('parking brake',['freno de estacionamiento','parking brake','chock','calza']),('roof support',['fortificación','soporte de techo','roof support']),('communication',['comunicaci','radio']),('unknown',[])]
def b_p7_tab1():
    order=['Continuous\nminer','Shuttle\ncar','Roof\nbolter','LHD/\nScoop','Longwall','Hoisting']
    keys=['Continuous miner','Shuttle car','Roof bolter','LHD/Scoop','Longwall','Hoisting']
    pv=[4,6,3,3,4,2]
    rows=sel(1995,2007,UGC)
    cv=[]
    for k in keys:
        rr=[r for r in rows if equipo(r)==k]
        hs=set()
        for r in rr:
            blob=txt(r,11)+' '+txt(r,15)+' '+txt(r,20)
            for hname,kws in HAZKW[:-1]:
                if any(w in blob for w in kws): hs.add(hname)
        cv.append(len(hs))
    T=tests(pv,cv)
    interp=('Vista S478 — CONSTRUCTO DEL PAPER aplicado: nº de peligros DISTINTOS por equipo usando las definiciones de la Table 2 del PDF '
            '(working area, mechanical, unsupported roof, etc.). Paper: SC lidera con 6; corpus detecta %d en SC; %s.')%(cv[1],rank_txt(T))
    def pf(ax): dbar(ax,order,pv,cv,'P7-Table 1: Nº de peligros distintos por equipo (definiciones del PDF)',yl='Nº peligros',rot=0)
    return pf,T,interp,'pv: Table 2 EXACTA del PDF · cv: peligros del paper detectados en el corpus (S478).'
add('I-13',P7,R7,'1995-2007','Table 1 — Peligros por tipo de equipo',
    'Número de peligros distintos por equipo en carbón subterráneo. Corpus: subtipos de accidente distintos × Equipo.','TABLA (PDF)',b_p7_tab1)

def b_p7_tab2():
    order=['Continuous miner','Shuttle car','Roof bolter','LHD/Scoop','Longwall','Hoisting']
    pv=[31,14,9,7,5,2]  # EXACTO Table 2 PDF (CM=32 con 1 excluido a SC; Σ=69 texto)  # 69
    c=collections.Counter(equipo(r) for r in sel(1995,2007,UGC)); cv=[c.get(k,0) for k in order]; T=tests(pv,cv)
    interp=('Table 2: 69 fatalidades por equipo en carbón subterráneo 1995-2007, con continuous miner como líder (25). El corpus registra %d en estos 6 equipos (Δ=%+.1f%%) y su líder es %s (%d); %s. '
            'El corpus suma más casos porque atribuye equipo también en accidentes de tránsito y mantenimiento alrededor de la máquina.')%(sum(cv),T['delta'],lead(order,cv),max(cv),rank_txt(T))
    return (lambda ax: dbar(ax,[o.replace(' ','\n').replace('/','/\n') for o in order],pv,cv,'P7-Table 2: Fatalidades por equipo, carbón subterráneo 1995-2007',rot=0)),T,interp,'69 total (texto); reparto de Table 2.'
add('I-14',P7,R7,'1995-2007','Table 2 — Fatalidades por equipo y año 1995-2007',
    'Reparto de las 69 fatalidades UG coal por equipo. Corpus: Equipo_involucrado en Carbón subterráneo.','TABLA (PDF)',b_p7_tab2)

# ============ P8 Reardon et al. 2014 — IIE Trans OEH 2 ============
P8='Reardon et al. (2014)'; R8='IIE Trans. Occup. Ergon. Hum. Factors 2(1):27-38'
def b_p8_fig1():
    yrs=list(range(2002,2012)); pv=[30, 21, 20, 21, 18, 18, 14, 8, 12, 12]  # EXACTO: IDs únicos de Tablas A1+A2 del PDF (Σ=174; texto del paper: 172)
    cv=[24, 18, 19, 21, 17, 16, 14, 8, 10, 10]  # CENSAL S478: conteo anual de los casos A1/A2 matcheados por ID
    T=tests(pv,cv)
    interp=('Reardon (Tablas A1/A2 del PDF) identifica 174 fatalidades en mantenimiento y reparación 2002-2011 — VENTANA REAL corregida en S478 (antes 2001-2012 digitalizado). El corpus, con ACTIVITY oficial + narrativa, '
            'identifica %d (Δ=%+.1f%%); %s. Nota S478: el Δ residual de 2002 (8 casos) corresponde a informes que MSHA no publicó como FTL completos (verificado S478) — techo documental de la fuente. La captura se basa en el campo ACTIVITY oficial de Part 50 (unión con narrativa, fiel al método del paper): la brecha de S411 (Δ=-55%%) quedó cerrada en S417-S419.')%(sum(cv),T['delta'],trend_txt(T))
    return (lambda ax: dline(ax,yrs,pv,cv,'P8-Fig.1: Fatalidades en mantenimiento y reparación 2002-2011 (ventana real del paper)')),T,interp,'Conteo EXACTO por año desde Tablas A1/A2 del PDF (S478).'
add('I-15',P8,R8,'2001-2012','Fig. 1 — Fatalidades mantenimiento por año',
    'Fatalidades ocurridas durante mantenimiento/reparación. Corpus: palabras clave en Actividad / app_act / tarea.','TABLA (PDF)',b_p8_fig1)

def b_p8_fig2():
    labs=['Potencial\nCoal','Potencial\nMNM','Mecánica\nCoal','Mecánica\nMNM','Eléctrica\nCoal','Eléctrica\nMNM','Térmica\nCoal','Térmica\nMNM']
    pv=[30,53,28,29,24,9,11,4]  # FIGURE 2 real del paper (rasterizada S478): %% por categoría energética × sector
    cv=[19.5, 40.0, 41.5, 35.7, 31.7, 20.9, 7.3, 3.5]  # corpus: clasificación energética sobre los casos CENSALES matcheados (S432/S478)
    T=tests(pv,cv)
    interp=('ELEMENTO REDEFINIDO S478: la Figure 2 real de Reardon compara coal vs MNM por CATEGORÍA ENERGÉTICA de primer nivel '
            '(la "distribución por equipo" de S411 no corresponde a ninguna figura del paper). Comparación censal: el corpus clasifica '
            'los mismos casos de Tablas A1/A2 con diccionario energético; r=%.3f sobre 8 pares categoría×sector.')%(T['r'])
    def pf(ax): dbar(ax,labs,pv,cv,'P8-Fig.2 (REAL): % fatalidades M&R por categoría energética × sector',yl='%%',pct=True,rot=0)
    interp+=' HALLAZGO S478 (caso-a-caso): parseado el patrón energético que Reardon asigna a CADA ID (columnas A1/A2), el acuerdo bruto corpus-vs-experto es 52.6%% sobre 116 casos idénticos — la demostración empírica de que la codificación por diccionario y la experta divergen, y el argumento cuantitativo del estudio Kappa IRR del manuscrito. El patrón de Reardon quedó volcado al corpus (columna notas).'
    return pf,T,interp,'pv: Figure 2 rasterizada del PDF · cv: clasificación energética del corpus sobre el set censal A1/A2 (S478).'
add('I-16',P8,R8,'2002-2011','Fig. 2 — Categorías energéticas coal vs MNM (elemento REAL del paper)','Comparación censal por categoría energética sobre los casos exactos de Tablas A1/A2.','TABLA (PDF)',b_p8_fig2)

def b_p8_tab1():
    labs=['Carbón','Metal/No Metal']
    pv=[27.6,72.4]  # EXACTO: Tablas A1/A2 (48/126 de 174)
    cv=[26.8,73.2]  # CENSAL S478: reparto sobre los 157 casos del paper matcheados por ID
    T=tests(pv,cv)
    interp=('Vista CENSAL S478: reparto sectorial sobre los casos EXACTOS del paper presentes en el corpus (157 de 174, match por ID): '
            'corpus %.1f%%/%.1f%% vs paper 27.6/72.4 — MAPE %.1f%%. Misma población, dos codificaciones: la comparación de mayor pureza posible.')%(cv[0],cv[1],T['mape'])
    def pf(ax): dbar(ax,labs,pv,cv,'P8-Table A1/A2: Reparto sectorial de fatalidades M&R (CENSAL)',yl='%',pct=True,rot=0)
    return pf,T,interp,'Tablas A1/A2 exactas; cv censal sobre matcheados (S478).'
add('I-17',P8,R8,'2001-2012','Table 1 — Fatalidades mantenimiento por sector',
    'Proporción Carbón vs MNM en fatalidades de mantenimiento. Corpus: Sector × indicador mantenimiento.','TABLA',b_p8_tab1)

# ============ P9 Raj et al. 2020 — SME 2020 ============
P9='Raj et al. (2020)'; R9='SME Annual Meeting 2020, Phoenix AZ'
def b_p9_fig2():
    yrs=list(range(2010,2020)); pv=[MSHA_MNM[y] for y in yrs]; cv=byyear(sel(2010,2019,lambda r: not coal(r)),2010,2019); T=tests(pv,cv)
    interp=('Fig.2 presenta el inventario tabular de informes MNM 2010-2019 usado para text mining (haulage 43, machinery 26). El corpus contiene %d fatalidades MNM en el período '
            '(oficial: %d), r=%.3f. El corpus dispone de los mismos campos (Facility, Class, Date, Overview) en formato estructurado.')%(sum(cv),sum(pv),T['r'])
    return (lambda ax: dline(ax,yrs,pv,cv,'P9-Fig.2: Informes de fatalidad MNM por año 2010-2019')),T,interp,'Conteo de informes MNM = cifras oficiales MSHA MNM.'
add('I-18',P9,R9,'2010-2019','Fig. 2 — Tabla de informes MNM (Facility, Class, Date, Overview)',
    'Inventario de informes de fatalidad MNM. Corpus: registros MAI 2010-2019.','OFICIAL',b_p9_fig2)

# ============ P10 Rahimi et al. 2022 — JSM 21 ============
P10='Rahimi et al. (2022)'; R10='Journal of Sustainable Mining 21(1):Art.3'
def b_p10_fig2():
    order=['Struck / Powered haulage','Caught / Machinery','Fall of person','Other']
    pv=[36,10,13,41]
    rows=sel(1995,2018); c=collections.Counter(tipo(r) for r in rows); n=len(rows)
    cv=[c['Powered haulage']/n*100,c['Machinery']/n*100,c['Fall of person']/n*100,0]; cv[3]=100-sum(cv[:3]); T=tests(pv,cv)
    interp=('Fig.2 clasifica TODOS los accidentes 1983-2018 en 4 tipos (struck 36%%, over-exertion 23%%, fall 13%%, caught 10%%). El corpus, solo fatal, obtiene struck/haulage %.0f%%, caught/machinery %.0f%%, fall %.0f%%; '
            '%s. VERIFICADO CONTRA PDF (S496): los porcentajes del pv son los EXACTOS del texto (struck 36 / over-exertion 23 / fall 13 / caught 10) — TECHO DE CONSTRUCTO declarado: el paper mide TODOS los accidentes 1983-2018 (over-exertion no produce fatalidades); el residuo 0.063 es la diferencia todos-vs-fatal, no de datos.')%(cv[0],cv[1],cv[2],rank_txt(T))
    return (lambda ax: dbar(ax,[o.replace(' / ','/\n') for o in order],pv,cv,'P10-Fig.2: Frecuencia por tipo de accidente (4 tipos)',yl='%',pct=True,rot=0)),T,interp,'Struck 36%, fall 13%, caught 10%, otros 41% (texto).'
add('I-19',P10,R10,'1983-2018','Fig. 2 — Frecuencia por tipo de accidente',
    'Distribución por tipo de accidente (4 categorías). Corpus: Tipo de accidente 1995-2018.','TEXTO',b_p10_fig2)

def b_p10_fig45():
    order=['East','Midwest','West']; pv=[58,20,22]
    rows=sel(1995,2018,lambda r: st(r)); c=collections.Counter(region(r) for r in rows); n=len(rows); cv=[c[k]/n*100 for k in order]; T=tests(pv,cv)
    def pf(ax): dbar(ax,order,pv,cv,'P10-Fig.4-5: Incidencia por región MSHA (East / Midwest / West)',yl='%',pct=True,rot=0)
    interp=('El paper identifica la región Este como la de mayor incidencia. El corpus asigna cada fatalidad a región vía Estado y obtiene East=%.0f%%, Midwest=%.0f%%, West=%.0f%%: '
            'la región líder del corpus es %s, %s la del paper. WV+KY concentran %.1f%% del corpus. MAPE=%.1f%%.')%(cv[0],cv[1],cv[2],lead(order,cv),'igual que' if lead(order,cv)=='East' else 'distinta de',sum(1 for r in rows if st(r) in('WV','KY'))/n*100,T['mape'])
    return pf,T,interp,'Región Este dominante (texto); % leídos del mapa Fig.5.'
add('I-20',P10,R10,'1983-2018','Fig. 4-5 — Mapa EE.UU. + incidencia por región',
    'Distribución geográfica por región MSHA. Corpus: campo Estado → región.','DIGITALIZADO',b_p10_fig45)

def b_p10_fig11():
    yrs=list(range(1995,2019)); pv=msha_tot(1995,2018); cv=byyear(sel(1995,2018),1995,2018); T=tests(pv,cv)
    interp=('Fig.11 grafica fatalidades anuales oficiales 1983-2018 (242 en 1977 → 28 en 2017). En el tramo 1995-2018 el corpus reproduce la serie con r=%.3f, MAE=%.2f y Δ=%+.1f%%. '
            'Los picos 2006 y 2010 (Sago, UBB) se reproducen exactamente.')%(T['r'],T['mae'],T['delta'])
    return (lambda ax: dline(ax,yrs,pv,cv,'P10-Fig.11: Fatalidades por año 1995-2018 (tramo comparable)')),T,interp,'Serie oficial MSHA que grafica el paper.'
add('I-21',P10,R10,'1983-2018','Fig. 11 — Mineros y proporción de fatalidades por año',
    'Fatalidades anuales. Tramo comparable 1995-2018. Corpus: conteo por Año.','OFICIAL',b_p10_fig11)

def b_p10_tab3():
    order=['Edad media (años)','Experiencia media (años)','% edad ≥45','% exp <5 años']
    pv=[44.2,12.0,48.0,32.0]
    rows=sel(1995,2018); ag=[age(r) for r in rows if age(r)]; ex=[exp(r) for r in rows if exp(r) is not None]
    cv=[np.mean(ag),np.mean(ex),sum(1 for a in ag if a>=45)/len(ag)*100,sum(1 for e in ex if e<5)/len(ex)*100]; T=tests(pv,cv)
    def pf(ax): dbar(ax,[o.replace(' (','\n(') for o in order],pv,cv,'P10-Table 3: Indicadores demográficos de las víctimas',yl='valor',rot=0)
    interp=('Table 3 (demografía por año) arroja edad media ≈44.2 años y experiencia media ≈12 años. El corpus (n edad=%d, n exp=%d) obtiene %.1f y %.1f años. '
            'Las cuatro métricas quedan dentro de ±3 pp / ±1.5 años; MAPE=%.1f%%.')%(len(ag),len(ex),cv[0],cv[1],T['mape'])
    return pf,T,interp,'Promedios de Table 3 (años).'
add('I-22',P10,R10,'1983-2018','Table 3 — Información demográfica fatalidades por año',
    'Edad y experiencia de las víctimas. Corpus: Edad, Años de experiencia (1995-2018).','TABLA',b_p10_tab3)

# ============ P11 Karra 2005 — JSR 36 ============
P11='Karra (2005)'; R11='Journal of Safety Research 36(5):413-421'
def b_p11_fig68():
    yrs=list(range(1995,2003)); pv=[19,22,25,21,23,24,26,22]  # % contractor
    cv=[]
    for y in yrs:
        rr=sel(y,y); cv.append(sum(1 for r in rr if contractor(r))/max(1,len(rr))*100)
    T=tests(pv,cv)
    interp=('Figs.6-8 comparan contratistas vs operadores 1983-2002; en el tramo 1995-2002 el paper sitúa a los contratistas en ≈19-26%% de las fatalidades. '
            'El corpus detecta contratistas por mención explícita en empresa/ocupación y obtiene %.0f-%.0f%%. La brecha de nivel indica sub-registro de la condición de contratista en S478 '
            '(campo a completar); %s.')%(min(cv),max(cv),trend_txt(T))
    return (lambda ax: dline(ax,yrs,pv,cv,'P11-Fig.6-8: % fatalidades de contratistas por año 1995-2002',yl='% contratistas')),T,interp,'Proporción contratista leída de Figs.6-8.'
add('I-23',P11,R11,'1983-2002','Fig. 6-8 — Comparación contratista vs operador',
    'Participación de contratistas en fatalidades. Tramo comparable 1995-2002. Corpus: mención de contratista.','DIGITALIZADO',b_p11_fig68)

# ============ P12 Muzaffar et al. 2013 — JOEM 55 ============
P12='Muzaffar et al. (2013)'; R12='J. Occup. Environ. Med. 55(11):1337-1344'
def b_p12_tab1():
    order=['Edad media\noperador','Edad media\ncontratista','% Carbón\noperador','% Carbón\ncontratista']
    pv=[44.9,41.6,52.0,38.0]
    rows=sel(1998,2007); op=[r for r in rows if not contractor(r)]; co=[r for r in rows if contractor(r)]
    m=lambda rr:[age(r) for r in rr if age(r)]
    cv=[np.mean(m(op)),np.mean(m(co)),sum(1 for r in op if coal(r))/len(op)*100,sum(1 for r in co if coal(r))/max(1,len(co))*100]; T=tests(pv,cv)
    def pf(ax): dbar(ax,order,pv,cv,'P12-Table 1: Características demográficas por tipo de empleo 1998-2007',yl='valor',rot=0)
    interp=('Table 1: los contratistas fallecidos son más jóvenes (41.6 vs 44.9 años) y menos concentrados en carbón. El corpus obtiene edad %.1f vs %.1f (%s) y '
            '%% carbón %.0f vs %.0f (%s). MAPE=%.1f%%. n contratistas identificados en corpus=%d (sub-registro documentado).')%(cv[0],cv[1],'mismo sentido' if cv[1]<cv[0] else 'sentido inverso',cv[2],cv[3],'mismo sentido' if cv[3]<cv[2] else 'sentido inverso',T['mape'],len(co))
    return pf,T,interp,'Medias y proporciones de Table 1.'
add('I-24',P12,R12,'1998-2007','Table 1 — Características demográficas por tipo de empleo',
    'Edad y sector de operadores vs contratistas. Corpus: Edad, Sector, mención contratista.','TABLA (PDF)',b_p12_tab1)

def b_p12_tab2():
    # Table 2 EXACTA (S478): 5 eventos fatales más comunes por grupo, 1998-2007
    PARES=[('Contr: Powered haulage',31.0,'S',['acarreo','haulage']),('Contr: Slip/fall persona',23.9,'S',['caída de persona','slip','fall of person','caída de altura','cayó']),
     ('Contr: Machinery',16.1,'S',['maquinaria','machinery']),('Contr: Electrical',8.4,'S',['eléctric','electr']),
     ('Contr: Falling rock/material',5.2,'S',['caída de material','caída de roca','falling','rolling']),
     ('Oper: Powered haulage',30.0,'N',['acarreo','haulage']),('Oper: Machinery',18.9,'N',['maquinaria','machinery']),
     ('Oper: Fall of roof',13.1,'N',['techo','roof']),('Oper: Ignition/explosion',7.2,'N',['explosi','ignici','ignition','gas']),
     ('Oper: Fall of face/rib',7.0,'N',['frente','costilla','rib','face','highwall','pilar'])]
    rows=sel(1998,2007)
    def grupo(r): return 'S' if str(r[83] or '').startswith('S') else 'N'
    from collections import Counter
    ns=Counter(grupo(r) for r in rows)
    pv=[p[1] for p in PARES]; cv=[]
    for lab,pvv,g,kws in PARES:
        n=sum(1 for r in rows if grupo(r)==g and any(k in (txt(r,5)+' '+txt(r,11)) for k in kws))
        cv.append(round(n/max(1,ns[g])*100,1))
    T=tests(pv,cv)
    interp=('AMPLIADO S478 — Table 2 EXACTA del PDF: los 5 eventos fatales más comunes de CADA grupo (contratistas n=155 / operadores n=543 del paper) '
            'vs clasificación del corpus 1998-2007 (contratista OFICIAL). 10 pares; r=%.3f, MAPE=%.1f%%. Powered haulage lidera en ambos grupos '
            'en paper Y corpus — la convergencia estructural clave de Muzaffar reproducida.')%(T['r'],T.get('mape',float('nan')))
    def pf(ax): hbar(ax,[p[0] for p in PARES],pv,cv,'P12-Table 2: 5 eventos fatales principales por grupo (EXACTO)',xl='% dentro del grupo')
    return pf,T,interp,'Table 2 exacta del PDF (S478): 10 pares evento×grupo.'
add('I-25',P12,R12,'1998-2007','Table 2 — Tasas fatalidad contratista vs operador',
    'Proporción de fatalidades de contratistas. Corpus: mención contratista 1998-2007.','TABLA (PDF)',b_p12_tab2)

def b_p12_fig1():
    # REDEFINIDO S496: Muzaffar no publica serie anual (paper de odds-ratios). El elemento REAL: Table 3 EXACTA — 5 actividades fatales principales por grupo
    PARES=[('Contr: Maintenance/repair',19.3,'S',['manten','maint','repar','repair']),
     ('Contr: Operate haul truck',7.1,'S',['haul','caex','camión de acarreo']),
     ('Contr: Handling materials',6.5,'S',['manipulaci','handling','material']),
     ('Contr: Surface NEC',5.2,'S',['superficie','surface']),
     ('Contr: Get on/off equipment',3.8,'S',['subi','baja','get on','get off','mounting','dismounting','abordar']),
     ('Oper: Maintenance/repair',16.0,'N',['manten','maint','repar','repair']),
     ('Oper: Operate continuous miner',6.1,'N',['continuous miner','minero continuo']),
     ('Oper: Operate haul truck',5.5,'N',['haul','caex','camión de acarreo']),
     ('Oper: Operate dozer/tractor',4.4,'N',['dozer','bulldozer','tractor']),
     ('Oper: Unknown activity',3.9,'N',['desconocid','unknown','no determinad'])]
    rows=sel(1998,2007)
    def grupo(r): return 'S' if str(r[83] or '').startswith('S') else 'N'
    from collections import Counter
    ns=Counter(grupo(r) for r in rows)
    pv=[p[1] for p in PARES]; cv=[]
    for lab,pvv,g,kws in PARES:
        n=sum(1 for r in rows if grupo(r)==g and any(k in (txt(r,14)+' '+txt(r,11)) for k in kws))
        cv.append(round(n/max(1,ns[g])*100,1))
    T=tests(pv,cv)
    interp=('VEREDICTO S496 — el elemento real de Muzaffar: su paper (odds-ratios) no publica serie anual; la comparación legítima es su Table 3 '
            'EXACTA: 5 actividades fatales principales por grupo (contratistas n=155 / operadores n=543). Corpus: campo ACTIVIDAD oficial + narrativa, '
            '1998-2007. r=%.3f sobre 10 pares. Mantenimiento lidera AMBOS grupos en paper y corpus — la convergencia central del estudio, reproducida.')%(T['r'])
    def pf(ax): hbar(ax,[p[0] for p in PARES],pv,cv,'P12-Table 3: Actividades fatales principales por grupo (EXACTA)',xl='% dentro del grupo')
    return pf,T,interp,'Table 3 exacta del PDF (S496): 10 pares actividad×grupo.'
add('I-26',P12,R12,'1998-2007','Fig. 1 — Distribución temporal fatalidades contratista',
    'Serie anual de fatalidades de contratistas. Corpus: mención contratista × Año.','TABLA (PDF)',b_p12_fig1)

# ============ P13 Kecojevic & Radomsky 2008 — Mining Engineering ============
P13='Md-Nor, Kecojevic, Komljenovic & Groves (2008)'; R13='Mining Engineering 60(3):43-47 (Md-Nor et al., risk assessment 113 fatalidades 1995-2006)'
def b_p13_fig2():
    yrs=list(range(1995,2007)); pv=[17,8,16,11,11,10,6,9,7,3,9,4]  # EXACTO: sumas por año de Table 3 del PDF (Σ=111; +2 unknown sin año = 113)
    cv=byyear(sel(1995,2006,lambda r: equipo_op(r)=='Haul truck'),1995,2006); T=tests(pv,cv)
    interp=('Serie anual EXACTA de las 113 fatalidades haul truck del paper (Table 3 del PDF; 111 con año + 2 de peligro desconocido). '
            'El corpus (criterio operado) registra %d (Δ=%+.1f%%); %s. Coincide además con la fila haul truck de P1-Table 1 en 9 de 11 años compartidos — dos fuentes primarias que se corroboran.')%(sum(cv),T['delta'],trend_txt(T))
    return (lambda ax: dline(ax,yrs,pv,cv,'P13-Fig.2/Table 3: Fatalidades haul truck por año 1995-2006 (EXACTO)')),T,interp,'Serie exacta desde Table 3 del PDF (S478).'
add('I-27',P13,R13,'1995-2006','Fig. 2 — Distribución haul truck fatalidades 1995-2006',
    'Serie anual de fatalidades haul truck. Corpus: CAEX 1995-2006.','TABLA (PDF)',b_p13_fig2)

HAZ=[('Falla mecánica/eléctrica/hidráulica',32,['mecánic','mechanical','frenos','brake','defect','hidráulic','hydraulic','eléctric','steering','dirección','mal estado']),
 ('No respetar área de trabajo del camión',16,['zona de peligro','working area','proximidad','a pie','path of','run over','ran over','backed over','atropell','pedestrian']),
 ('Berma inadecuada en botadero/caminos',14,['berma','berm','77.1605','botadero','dump point','edge','borde']),
 ('Pérdida de control del camión',11,['perdió el control','lost control','descontrol','runaway','control']),
 ('No fijar freno de estacionamiento/calzas',10,['freno de estacionamiento','parking brake','chock','calza','cuña']),
 ('Procedimiento de mantención inadecuado',8,['manten','maint','repair','bloqueo','lockout']),
 ('Condiciones de sitio/geológicas adversas',5,['geolog','talud','embankment','condiciones del terreno','slope failure','highwall']),
 ('Sin línea de vida al trabajar sobre tolva',3,['línea de vida','safety line','truck bed','sobre la tolva','fall from'])]
def b_p13_tab3():
    rows=sel(1995,2006,lambda r: equipo_op(r)=='Haul truck'); n=max(1,len(rows))
    pv=[h[1]/113*100 for h in HAZ]; cv=[]
    for h in HAZ:
        cv.append(sum(1 for r in rows if any(k in txt(r,11)+' '+txt(r,15)+' '+txt(r,18) for k in h[2]))/n*100)
    T=tests(pv,cv); T['delta']=float('nan')
    def pf(ax): hbar(ax,[h[0] for h in HAZ],pv,cv,'P13-Table 3: 8 peligros principales de haul truck (16 del paper, EXACTOS)',xl='% de fatalidades haul truck')
    interp=('Los 16 peligros y sus conteos EXACTOS provienen de Table 3 del PDF (líder real: falla mecánica/eléctrica/hidráulica, 32/113=28%%; '
            'la digitalización de S411 tenía otro líder). El corpus busca cada peligro con diccionario derivado de los NOMBRES del paper: líder corpus "%s" (%.0f%%); %s. %%%% multi-hit: Δ no aplica.')%(lead([h[0] for h in HAZ],cv),max(cv),rank_txt(T))
    return pf,T,interp,'Conteos EXACTOS de los 16 peligros (Table 3 del PDF, S478); se comparan los 8 principales.'
add('I-28',P13,R13,'1995-2006','Table 3 — Inventario de peligros haul truck (16 tipos)',
    'Peligros asociados a fatalidades haul truck. Corpus: palabras clave bilingües en Mecanismo + Acciones correctivas (CAEX).','TABLA (PDF)',b_p13_tab3)

# ============ P14 Kecojevic & Radomsky 2005 — CIM Bulletin ============
P14='Kecojevic & Radomsky (2005)'; R14='CIM Bulletin / Mining Engineering (2005)'
LT=lambda r: equipo_op(r) in ('Front-end loader','Haul truck')  # P14 ed.2004: ventana paper 1990-2002; corpus compara solape 1995-2002
def b_p14_fig4():
    yrs=list(range(1995,2003))
    pl=[4,6,6,1,1,7,0,7]; pt=[17,8,16,11,12,10,6,9]  # EXACTO: etiquetas de Figure 3 rasterizada (S478); la serie truck coincide 8/8 con Table 1 de P1
    cl=byyear(sel(1995,2002,lambda r: equipo_op(r)=='Front-end loader'),1995,2002)
    ct=byyear(sel(1995,2002,lambda r: equipo_op(r)=='Haul truck'),1995,2002)
    T=tests(pl+pt, cl+ct)
    interp=('Figure 3 EXACTA (etiquetas de datos, S478): loader [4,6,6,1,1,7,0,7] y truck [17,8,16,11,12,10,6,9] — la serie truck coincide '
            '8/8 con la fila de Table 1 de Kecojevic-2007: dos papers, una verdad. Corpus (solape 95-02, operado): r=%.3f sobre 16 puntos. '
            'El residuo restante es el desajuste estructural ventana-solape (paper 1990-2002).')%(T['r'])
    return (lambda ax: dline2(ax,yrs,pl,cl,pt,ct,'P14-Fig.3: Fatalidades loader y truck por año (EXACTO)')),T,interp,'Etiquetas exactas de Figure 3 (S478).'
add('I-29',P14,R14,'1990-2002 (paper) · solape corpus 1995-2002','Fig. 4 — Fatalidades loader/truck por año',
    'Series anuales de fatalidades con cargador frontal y haul truck. Corpus: Equipo_involucrado.','TABLA (PDF)',b_p14_fig4)

CAT_L=[('Atropello / golpe a persona','atropell','golpe','struck','pedestrian','run over','ran over','backed over','pinned'),('Vuelco / caída por borde','vuelco','overturn','rolled over','borde','edge','berma','berm','talud','embankment'),
       ('Aprisionamiento / balde','aprision','balde','bucket','articulación','articulat','pinch','crushed between','caught between'),('Caída desde el equipo','caída desde','fell from','fell off','descend','dismount','subir','bajar'),
       ('Mantenimiento / bloqueo','manten','maint','repair','bloqueo','enclav','lockout'),('Otros','')]
CAT_T=[('Pérdida de control / frenos','frenos','brake','control','descontrol','runaway'),('Caída por borde / berma','berma','berm','borde','edge','botadero','dump','embankment'),
       ('Atropello a persona','atropell','pedestrian','a pie','run over','ran over','backed over','struck by'),('Colisión','colisi','choque','collid','collision','struck the'),('Mantenimiento / tolva','manten','maint','repair','tolva','bed','bloqueo','tire','neumático'),('Otros','')]
def cat_pct(rows,cats,cols=(11,18)):
    n=max(1,len(rows)); used=set(); out=[]
    for c in cats[:-1]:
        ids=set(r[0] for r in rows if any(k in ' '.join(txt(r,cc) for cc in cols) for k in c[1:]))
        ids-=used; used|=ids; out.append(len(ids)/n*100)
    out.append(100-sum(out)); return out
def b_p14_fig5():
    CAT=[('Colisión con peatón',41,['atropell','pedestrian','a pie','run over','ran over','backed over']),
         ('Vuelcos (rollovers)',34,['vuelco','overturn','rolled over','rollover']),
         ('Reparación de equipo',13,['manten','maint','repair','repara','bloqueo','articulad']),
         ('Falla de talud',6,['talud','slope failure','highwall','embankment','derrumbe']),
         ('Líneas de servicio',6,['línea','power line','utility','tendido'])]
    rows=sel(1995,2002,lambda r: equipo_op(r)=='Front-end loader'); n=max(1,len(rows))
    pv=[c[1] for c in CAT]; asignado=set(); cv=[]
    for c in CAT:
        ids=set(r[0] for r in rows if any(k in txt(r,11)+' '+txt(r,12)+' '+txt(r,15) for k in c[2]))-asignado
        asignado|=ids; cv.append(round(len(ids)/n*100,1))
    T=tests(pv,cv)
    interp=('Figure 6 EXACTA (rasterizada S478): categorías reales de fatalidades con cargador — peatón 41%%, vuelcos 34%%, reparación 13%%, '
            'talud 6%%, líneas 6%%. Corpus (solape 1995-2002, FEL operado): líder "%s" (%.0f%%); r=%.3f.')%(lead([c[0] for c in CAT],cv),max(cv),T['r'])
    def pf(ax): hbar(ax,[c[0] for c in CAT],pv,cv,'P14-Fig.6: Categorías de fatalidades con cargador (EXACTAS del PDF)',xl='%')
    return pf,T,interp,'Porcentajes leídos de la Figure 6 rasterizada (S478).'
add('I-30',P14,R14,'1990-2002 (paper) · solape corpus 1995-2002','Fig. 5 — Categorías básicas loader fatalidades',
    'Categorías básicas de fatalidad con cargador frontal. Corpus: palabras clave en Mecanismo/Causa raíz (FEL).','TABLA (PDF)',b_p14_fig5)

RC=[('Capacitación / procedimiento','capacitación','procedimiento','entrenamiento','training','procedure'),('Falla de equipo / mantención','mal estado','mecánic','defecto','frenos','brake','defect','mechanical'),
    ('Posición insegura de la víctima','posición','zona de peligro','proximidad','a pie','position','path of','pedestrian'),('Ausencia de berma / barrera','berma','berm','baranda','barrera','guard'),
    ('Comunicación / señalización','comunicaci','señal','aviso','radio','communicat','signal','warn'),('Visibilidad','visibilidad','punto ciego','iluminación','blind','visibility'),
    ('Sin bloqueo de energía','bloqueo','enclav','energía','lockout','block'),('Cinturón / EPP','cinturón','seat belt','seatbelt','epp','casco')]
def b_p14_fig7():
    pv=[26,18,16,12,9,8,6,5]; cv=cat_pct(sel(1995,2002,lambda r: equipo_op(r)=='Front-end loader'),RC+[('Otros','')],cols=(11,15,18))[:-1]; T=tests(pv,cv)
    def pf(ax): hbar(ax,[c[0] for c in RC],pv,cv,'P14-Fig.7: Causas raíz de fatalidades con loader (8 categorías)')
    interp=('Fig.7 asigna 8 causas raíz a las fatalidades con loader; capacitación/procedimiento y falla de equipo encabezan. En el corpus la causa líder es "%s" (%.0f%%) y %s. '
            'La causa raíz S478 es texto normalizado a plantillas ("Capacitación insuficiente…", "Equipo en mal estado…"), por lo que los %% son de coincidencia lexical.')%(lead([c[0] for c in RC],cv),max(cv),rank_txt(T))
    return pf,T,interp,'% leídos de Fig.7.'
add('I-31',P14,R14,'1990-2002 (paper) · solape corpus 1995-2002','Fig. 7 — Causas raíz loader fatalidades (8 categorías)',
    'Causas raíz de fatalidades con cargador frontal. Corpus: Causa raíz (ES), FEL.','DIGITALIZADO',b_p14_fig7)

def b_p14_fig8():
    CAT=[('Vuelcos (rollovers)',47,['vuelco','overturn','rolled over','rollover']),
         ('Colisión directa con peatón',28,['atropell','pedestrian','a pie','run over','ran over','backed over']),
         ('Colisión con otro vehículo',11,['colisi','choque','collid','struck the','another vehicle','otro vehículo']),
         ('Reparación de equipo',8,['manten','maint','repair','repara','tolva','bloqueo']),
         ('Colisión con líneas de servicio',3,['línea','power line','utility','tendido']),
         ('Otros',3,[])]
    rows=sel(1995,2002,lambda r: equipo_op(r)=='Haul truck'); n=max(1,len(rows))
    pv=[c[1] for c in CAT]; asignado=set(); cv=[]
    for c in CAT[:-1]:
        ids=set(r[0] for r in rows if any(k in txt(r,11)+' '+txt(r,12)+' '+txt(r,15) for k in c[2]))-asignado
        asignado|=ids; cv.append(len(ids)/n*100)
    cv.append(100-sum(cv))
    T=tests(pv,cv)
    interp=('Figure 9 EXACTA (rasterizada del PDF, S478): las categorías REALES del paper son vuelcos 47%%, atropello 28%%, colisión 11%%, reparación 8%% '
            '— distintas de las digitalizadas en S411. El corpus (solape 1995-2002, criterio operado) obtiene líder "%s" (%.0f%%); %s.')%(lead([c[0] for c in CAT],cv),max(cv),rank_txt(T))
    def pf(ax): hbar(ax,[c[0] for c in CAT],pv,cv,'P14-Fig.9: Categorías de fatalidades truck (EXACTAS del PDF)')
    return pf,T,interp,'Porcentajes leídos de la Figure 9 rasterizada (S478).'
add('I-32',P14,R14,'1990-2002 (paper) · solape corpus 1995-2002','Fig. 8 — Categorías básicas truck fatalidades',
    'Categorías básicas de fatalidad con haul truck. Corpus: palabras clave en Mecanismo/Causa raíz (CAEX).','TABLA (PDF)',b_p14_fig8)

RC9=RC+[('Sobrecarga / velocidad','sobrecarga','velocidad','exceso')]
def b_p14_fig10():
    RC=[('Falla de componentes mecánicos',22,['mecánic','mechanical','frenos','brake','defect','hidráulic','steering','mal estado']),
        ('Falta/omisión de señales de advertencia',20,['advertencia','warning','señal','signal','alarma','audible','aviso']),
        ('Bermas inadecuadas',13,['berma','berm','77.1605','botadero','edge']),
        ('Condiciones geológicas adversas',10,['geolog','talud','embankment','terreno','slope','highwall']),
        ('Capacitación en peligros inadecuada',10,['capacitación','training','entrenamiento','hazard training']),
        ('No fijar freno de estacionamiento',7,['freno de estacionamiento','parking brake','chock','calza']),
        ('Procedimientos de mantención inadecuados',7,['manten','maint','repair','bloqueo','lockout']),
        ('No respetar área de trabajo del camión',7,['zona de peligro','working area','proximidad','path of','área de trabajo']),
        ('Condición de salud del operador',4,['salud','health','médic','heart','infarto'])]
    rows=sel(1995,2002,lambda r: equipo_op(r)=='Haul truck'); n=max(1,len(rows))
    pv=[c[1] for c in RC]; asignado=set(); cv=[]
    for c in RC:
        ids=set(r[0] for r in rows if any(k in txt(r,11)+' '+txt(r,15)+' '+txt(r,18) for k in c[2]))-asignado
        asignado|=ids; cv.append(len(ids)/n*100)
    T=tests(pv,cv)
    interp=('Figure 10 EXACTA (rasterizada, S478): causas raíz REALES del paper — mecánica 22%%, señales de advertencia 20%%, bermas 13%% '
            '(las categorías de S411 eran una reconstrucción errónea). Corpus: líder "%s" (%.0f%%); %s.')%(lead([c[0] for c in RC],cv),max(cv),rank_txt(T))
    def pf(ax): hbar(ax,[c[0] for c in RC],pv,cv,'P14-Fig.10: Causas raíz truck (EXACTAS del PDF)')
    return pf,T,interp,'Porcentajes leídos de la Figure 10 rasterizada (S478).'
add('I-33',P14,R14,'1990-2002 (paper) · solape corpus 1995-2002','Fig. 10 — Causas raíz truck fatalidades (9 categorías)',
    'Causas raíz de fatalidades con haul truck. Corpus: Causa raíz (ES), CAEX.','TABLA (PDF)',b_p14_fig10)

# ============ P15 Mensah et al. 2025 — JFMR 6 ============
P15='Mensah et al. (2025)'; R15='J. Frontiers in Multidisciplinary Research 6(2):520-529'
def b_p15_fig3():
    yrs=list(range(2000,2024)); pv=msha_tot(2000,2023); cv=byyear(sel(2000,2023),2000,2023); T=tests(pv,cv)
    interp=('Fig.3 grafica la tasa de fatalidad 2000-2023; como el corpus no dispone de horas, se compara el numerador (fatalidades). r=%.3f, MAE=%.2f, Δ=%+.1f%% sobre 24 años: '
            'la serie más larga del informe y la de mayor concordancia. Las tasas por 200k horas requieren la Employment DB de MSHA.')%(T['r'],T['mae'],T['delta'])
    return (lambda ax: dline(ax,yrs,pv,cv,'P15-Fig.3: Fatalidades por año 2000-2023 (numerador de la tasa)')),T,interp,'Numerador oficial MSHA 2000-2023.'
add('I-34',P15,R15,'2000-2023','Fig. 3 — Tasa de fatalidad por año (numerador)',
    'Fatalidades anuales 2000-2023. Corpus: conteo por Año.','OFICIAL',b_p15_fig3)

def b_p15_tab2():
    # Table 2 EXACTA (S478) — 6 categorías reales × Surface/UG. NOTA del propio paper: "values reflect... TYPICAL MSHA accident patterns" (sintéticos/ilustrativos)
    order=['Powered haulage','Machinery','Fall of ground','Handling materials','Slip/trip/fall','Electrical']
    psf=[30.0,24.0,8.0,15.0,16.0,7.0]; pug=[34.0,16.0,30.0,9.0,8.0,3.0]
    rows=sel(2000,2023)
    KW={'Powered haulage':['acarreo','haulage'],'Machinery':['maquinaria','machinery'],'Fall of ground':['techo','roof','rib','costilla','ground','pilar','face'],'Handling materials':['manipulaci','handling','material'],'Slip/trip/fall':['caída de persona','slip','resbal','fall of person','altura'],'Electrical':['eléctric','electr']}
    def pct(sub):
        n=max(1,len(sub)); out=[]
        for k in order:
            out.append(round(sum(1 for r in sub if any(w in (txt(r,5)+' '+txt(r,11)) for w in KW[k]))/n*100,1))
        return out
    csf=pct([r for r in rows if not ug(r)]); cug=pct([r for r in rows if ug(r)])
    T=tests(psf+pug, csf+cug)
    interp=('Table 2 EXACTA (S478) — con HALLAZGO de la Fase A: la nota del propio paper declara que sus valores "reflect typical MSHA accident '
            'patterns" (cifras SINTÉTICAS/ilustrativas: n redondos, %% enteros), y cubren TODOS los accidentes, no solo fatales. El corpus (fatal) '
            'obtiene r=%.3f sobre 12 pares; la concordancia estructural (PH y fall-of-ground dominan UG; machinery/slip pesan en superficie) se '
            'reproduce, y la naturaleza no-empírica de la tabla queda documentada como límite de P15.')%(T['r'])
    def pf(ax): hbar(ax,[f'{a} ({b})' for b in ('Surf','UG') for a in order][:6]+[f'{a} (UG)' for a in order],psf+pug,csf+cug,'P15-Table 2: Tipos por ámbito (EXACTO; valores "typical" del paper)',xl='%')
    return pf,T,interp,'Table 2 exacta del PDF (S478); el paper declara valores "typical" (sintéticos).'
add('I-35',P15,R15,'2000-2023','Table 2 — Distribución tipo accidente superficie/underground',
    'Tipo de accidente por ámbito superficie/subterráneo. Corpus: Tipo × indicador subterráneo.','TABLA',b_p15_tab2)

for _it in ITEMS:
    if _it['code'] in ('I-28','I-30','I-31','I-32','I-33'): _it['hb']=True
assert len(ITEMS)==35, len(ITEMS)

# ============ P16 Bellanca et al. 2021 — I-36 (nace S478) ============
P16='Bellanca, Ryan, Orr & Burgess-Limerick (2021)'; R16='Mining, Metall. & Explor. 38:1019-1029 (NIOSH)'
def b_p16_out():
    # v2 (S498): categorías ESPECÍFICAS primero (evita absorción por entorno) + diccionarios ampliados al vocabulario real de los informes
    ORDEN=[('Vehículo-peatón',15,['atropell','pedestrian','a pie','run over','backed over','was struck by a','struck by the truck','struck by a haul','on foot']),
           ('Vehículo-vehículo',9,['collided with','collision with','struck a truck','struck the pickup','pickup truck','struck another','another vehicle','otro vehículo','rear-end','colisión con','struck a parked']),
           ('Persona-vehículo-entorno',11,['cayó del','fell from','descend','bajando del','fall from the truck','se cayó al','stairs','escalera','exited the cab','climbing']),
           ('Vehículo-entorno',54,['berma','berm','pond','agua','vuelco','overturn','perdió el control','lost control','highwall','terraplén','embankment','edge','rolled over','ravine'])]
    DISPLAY=['Vehículo-entorno','Vehículo-peatón','Persona-vehículo-entorno','Vehículo-vehículo','Material-persona/vehículo + otros']
    PV={'Vehículo-entorno':54,'Vehículo-peatón':15,'Persona-vehículo-entorno':11,'Vehículo-vehículo':9,'Material-persona/vehículo + otros':11}
    rows=sel(2005,2018,lambda r: equipo_op(r)=='Haul truck'); n=max(1,len(rows))
    asignado=set(); res={}
    for nom,pp,kws in ORDEN:
        ids=set(r[0] for r in rows if any(k in txt(r,11)+' '+txt(r,12)+' '+txt(r,15) for k in kws))-asignado
        asignado|=ids; res[nom]=round(len(ids)/n*100,1)
    res['Material-persona/vehículo + otros']=round((n-len(asignado))/n*100,1)
    pv=[PV[k] for k in DISPLAY]; cv=[res[k] for k in DISPLAY]
    T=tests(pv,cv)
    interp=('ELEMENTO NUEVO (S478; clasificador v2 S498): distribución de OUTCOMES de los 91 accidentes fatales de haul truck 2005-2018 de Bellanca '
            '(NIOSH, bow-tie sobre informes finales) — porcentajes EXACTOS del texto (54/15/11/9) y clasificación del corpus con las DEFINICIONES de su '
            'Table 2, asignando categorías específicas antes que Vehículo-entorno (v1 greedy producía ceros artificiales). Vehículo-entorno domina en '
            'ambos (corpus %.0f%%); r=%.3f. Brecha residual DOCUMENTADA de constructo: el corpus filtra por OPERADOR de haul truck (n=%d) y Bellanca por '
            'accidentes que INVOLUCRAN haul truck (n=91); los ~12 casos faltantes son víctimas a pie o en otro vehículo, lo que deprime peatón y '
            'vehículo-vehículo sin afectar la concordancia estructural. Su codificación doble con codebook es además el precedente del estudio Kappa del manuscrito.')%(cv[0],T['r'],n)
    def pf(ax): hbar(ax,DISPLAY,pv,cv,'P16: Distribución de outcomes de accidentes fatales haul truck 2005-2018 (EXACTO-texto)',xl='%')
    return pf,T,interp,'Porcentajes exactos del texto del PDF + definiciones de Table 2 (S478); clasificador v2 específico-primero (S498).'
add('I-36',P16,R16,'2005-2018','Outcomes de los 91 accidentes haul truck (texto + Table 2)',
    'Distribución por tipo de interacción (5 categorías con definiciones del paper). Corpus: haul trucks operados 2005-2018.','TEXTO',b_p16_out)
