# -*- coding: utf-8 -*-
from lib import *
from items import ITEMS
from matplotlib.backends.backend_pdf import PdfPages
import textwrap

OUT='/home/claude/InformeComparativo_36elementos_S536.pdf'
INV=[('P1','Kecojevic, Komljenovic, Groves & Radomsky (2007)','Safety Science','1995-2005',2,7,9,5,3,0),
     ('P2','Groves, Kecojevic & Komljenovic (2007)','J. Safety Research','1995-2004',4,5,9,2,3,2),
     ('P3','Zhang, Kecojevic & Komljenovic (2014)','Safety Science','1995-2011',10,13,23,2,3,2),
     ('P4','Coleman & Kerkering (2007)','J. Safety Research','1983-2004',6,9,15,1,1,3),
     ('P5','Dindarloo, Pollard & Siami-Irdemoosa (2016)','J. Safety Research','2008-2014',9,7,16,0,3,2),
     ('P6','Amoako, Buaba & Brickey (2021)','Mining, Metall. & Explor.','2008-2019',16,13,29,1,3,1),
     ('P7','Kecojevic & Md Nor (2009)','J. Coal Sci. & Eng.','1995-2007',2,1,3,3,0,0),
     ('P8','Reardon, Heberger & Dempsey (2014)','IIE Trans. OEH Factors','2001-2012',3,2,5,3,2,0),
     ('P9','Raj et al. (2020)','SME Annual Meeting','2010-2019',0,15,15,1,2,2),
     ('P10','Rahimi, Shekarian, Shekarian & Roghanchi (2022)','J. Sustainable Mining','1983-2018',10,12,22,4,4,1),
     ('P11','Karra (2005)','J. Safety Research','1983-2002',6,8,14,1,1,3),
     ('P12','Muzaffar, Cummings, Hobbs, Allison & Kreiss (2013)','JOEM','1998-2007',9,1,10,3,2,1),
     ('P13','Kecojevic & Radomsky (2008)','Mining Engineering','1995-2006',5,3,8,2,2,1),
     ('P14','Kecojevic & Radomsky (2005)','CIM Bulletin','1995-2005',0,16,16,5,1,1),
     ('P15','Mensah, Yeboah, Saah, Nii-Okai, Miezah & Wiafe (2025)','J. Front. Multidisc. Res.','2000-2023',5,9,14,2,2,4),
 ('P16','Bellanca, Ryan, Orr & Burgess-Limerick (2021)','Mining, Metall. & Explor. 38','2005-2018',3,2,5,1,2,2),
 ('P17','Pollard, Heberger & Dempsey (2014)','J. Quality in Maintenance Eng. 20(1)','2002-2011',2,3,5,0,1,4)]

# ---- pre-build all items (compute tests first for index/summary) ----
BUILT=[]
for it in ITEMS:
    pf,T,interp,note=it['builder']()
    T=aplicar_divergencia(it['code'],T)
    it['interp']=interp; BUILT.append((it,pf,T,note))
    print('  ok',it['code'],T['qual'])

FIRST_ITEM_PAGE=5
with PdfPages(OUT) as pdf:
    # ================= 1. PORTADA =================
    fig,ax=blank_page()
    rct(ax,0,0,LW,LH,facecolor='#0D1F3C'); rct(ax,0,LH-0.85,LW,0.85,facecolor=NAVY)
    ax.text(LW/2,LH-0.42,'INFORME COMPARATIVO: PAPERS MSHA vs FatalityCheck S535',ha='center',va='center',fontsize=21,fontweight='bold',color='white')
    ax.text(LW/2,7.15,'Reproducción de los 36 elementos (tablas y figuras) reproducibles de 17 papers académicos',ha='center',fontsize=13,color=GOLD)
    ax.text(LW/2,6.8,'con tests de similitud estadística — Base de datos: FatalityCheck S535',ha='center',fontsize=11,color='#C8D0E0')
    cards=[('36','elementos reproducidos\n(de 218 inventariados)'),('17','papers académicos\ncon datos MSHA'),('S535','versión del corpus\n(05-sep-2026)'),('1,654','registros verificados\n1995-2026'),('6','tests de similitud\npor elemento')]
    for i,(v,l) in enumerate(cards):
        x0=0.45+i*2.05
        rct(ax,x0,5.25,1.9,1.25,facecolor=GOLD,alpha=0.15,edgecolor=GOLD,lw=1.3)
        ax.text(x0+0.95,6.1,v,ha='center',va='center',fontsize=21,fontweight='bold',color=GOLD)
        ax.text(x0+0.95,5.55,l,ha='center',va='center',fontsize=7.5,color='white')
    rct(ax,0.45,3.35,5.0,1.65,facecolor='#1a3a6e')
    ax.text(0.65,4.78,'Base de datos utilizada',fontsize=9,fontweight='bold',color=GOLD)
    for i,l in enumerate(['FatalityCheck S535 — Corpus longitudinal verificado de accidentes fatales, minería EE.UU.',
                          '1,654 registros activos · 275 columnas · 1995-2026 · Sesión S535 (post-auditoría)',
                          'Validación vs Part 50: r=0.970 · ρ=0.955 · Lin CCC=0.967 · balance anual EXACTO',
                          'Fuente primaria: informes de investigación MSHA (30 CFR Part 50) + miningincidents.org',
                          'Referencias: inventario de 218 elementos (17 papers) · Paquete_PAPER_FatalityCheck_S497.zip']):
        ax.text(0.65,4.5-i*0.24,l,fontsize=7.5,color='white')
    rct(ax,5.7,3.35,4.85,1.65,facecolor='#1a3a6e')
    ax.text(5.9,4.78,'Tests de similitud aplicados a cada elemento',fontsize=9,fontweight='bold',color=GOLD)
    for i,l in enumerate(['Pearson r — correlación lineal (con p-valor)','Spearman ρ — correlación de rangos (con p-valor)',
                          'RMSE — raíz del error cuadrático medio','MAE — error absoluto medio','MAPE — error porcentual absoluto medio','Δ Total — diferencia relativa de totales']):
        ax.text(5.9,4.5-i*0.24,'•  '+l,fontsize=7.5,color='white')
    rct(ax,0.45,2.35,10.1,0.8,facecolor='#1a3a6e')
    ax.text(0.65,2.95,'Escala de calificación',fontsize=8.5,fontweight='bold',color=GOLD)
    for i,(q,c) in enumerate([('EXCELENTE  r ≥ 0.95',TEAL),('BUENO  0.85 ≤ r < 0.95',NAVY),('ACEPTABLE  0.70 ≤ r < 0.85',GOLD),('PARCIAL  r < 0.70',RED)]):
        x=0.65+i*2.45; rct(ax,x,2.42,2.3,0.42,facecolor=c,alpha=0.25,edgecolor=c,lw=0.8)
        ax.text(x+1.15,2.63,q,ha='center',va='center',fontsize=8,fontweight='bold',color='white')
    ax.text(LW/2,1.7,'Estructura: portada · índice de elementos · metodología de tests · inventario de papers · 35 páginas (1 elemento = 1 página: figura + tests + interpretación) · resumen global · conclusiones',
            ha='center',fontsize=7.5,color='#C8D0E0')
    rct(ax,0,0,LW,0.6,facecolor='#060F1F')
    ax.text(LW/2,0.3,'Invictum SPA · Copiapó, Chile · corpus@invictum.cl · 04 de septiembre de 2026 · Formato carta horizontal (11 × 8.5 in)',ha='center',fontsize=8.5,color=GOLD)
    pdf.savefig(fig); plt.close(fig)

    # ================= 2. ÍNDICE =================
    fig,ax=blank_page(); header(ax,'Índice de gráficos y tablas reproducidos (35 elementos)'); footer(ax,2)
    cols=[(0.3,'Nº'),(0.85,'Paper'),(3.35,'Elemento reproducido'),(7.55,'Período'),(8.5,'Procedencia'),(9.75,'Calif.'),(10.58,'Pág.')]
    y=LH-0.85; rh=0.184
    rct(ax,0.2,y-rh,LW-0.4,rh,facecolor=NAVY)
    for x,h in cols: ax.text(x,y-rh/2,h,fontsize=7,fontweight='bold',color='white',va='center')
    y-=rh
    for i,(it,pf,T,note) in enumerate(BUILT):
        rct(ax,0.2,y-rh,LW-0.4,rh,facecolor=LIGHT if i%2==0 else 'white')
        per_ix=it['period'].replace(' (paper) · solape corpus ',' ⊃ ').replace('1995-','95-').replace('2002','02') if len(it['period'])>18 else it['period']
        per_ix=textwrap.shorten(per_ix,18,placeholder='…')
        qual_ix=T['qual'].replace('DIVERGENCIA DOC.','DIVERG. DOC.')
        vals=[it['code'],it['paper'],textwrap.shorten(it['element'],62),per_ix,it['prov'],qual_ix,str(FIRST_ITEM_PAGE+i)]
        for (x,_),v in zip(cols,vals):
            ax.text(x,y-rh/2,v,fontsize=6.4,va='center',color=T['qcol'] if v==qual_ix else DARK,fontweight='bold' if v==qual_ix else 'normal')
        y-=rh
    y-=0.05
    extra=[('1','Portada'),('2','Índice de gráficos y tablas'),('3','Metodología: descripción de los tests de similitud'),('4','Inventario de los 17 papers y sus 218 elementos'),
           (str(FIRST_ITEM_PAGE+35),'Resumen global de tests de similitud (35 elementos)'),(str(FIRST_ITEM_PAGE+36),'Conclusiones')]
    for j,l in enumerate(textwrap.wrap('Otras páginas:  '+'   ·   '.join('%s → pág. %s'%(bb,a) for a,bb in extra),190)):
        ax.text(0.3,y-0.05-j*0.17,l,fontsize=6.5,color=GRAY,va='top')
    pdf.savefig(fig); plt.close(fig)

    # ================= 3. METODOLOGÍA =================
    fig,ax=blank_page(); header(ax,'Metodología — Descripción de los tests de similitud aplicados'); footer(ax,3)
    tests_info=[
     ('Coeficiente r de Pearson',NAVY,'r = Σ(pᵢ−p̄)(cᵢ−c̄) / √[Σ(pᵢ−p̄)² · Σ(cᵢ−c̄)²]',
      ['Mide la correlación lineal entre la serie del paper (p) y la del corpus (c). Rango −1 a +1.',
       'H₀: r = 0. Se reporta el p-valor bilateral; con p < 0.05 la correlación es significativa al 95%.',
       'Es la base de la calificación global cuando n ≥ 4 puntos. Con n < 4 no se calcula (se usa MAPE).',
       'Limitación: no detecta diferencias de nivel (escala); por eso se acompaña de Δ Total y MAE.']),
     ('Coeficiente ρ de Spearman',TEAL,'ρ = 1 − 6·Σdᵢ² / [n(n²−1)],  dᵢ = rango(pᵢ) − rango(cᵢ)',
      ['Correlación no paramétrica sobre los rangos. No asume normalidad ni linealidad.',
       'Robusto ante valores extremos (p. ej. Upper Big Branch 2010, 29 víctimas).',
       'Si ρ ≈ r la relación es esencialmente lineal; si ρ ≫ r hay concordancia de orden con escala distinta.',
       'Es el test de referencia en las comparaciones de ranking de categorías (equipos, causas raíz).']),
     ('RMSE — Root Mean Squared Error',PURPLE,'RMSE = √[ Σ(pᵢ − cᵢ)² / n ]',
      ['Magnitud típica de la desviación, en las mismas unidades que los datos (fatalidades o puntos %).',
       'Penaliza cuadráticamente las desviaciones grandes: un año muy desviado eleva mucho el RMSE.',
       'Se lee junto con r: r alto + RMSE bajo = series casi superpuestas.',
       'Útil para comparar la precisión entre elementos de la misma unidad.']),
     ('MAE — Mean Absolute Error',ORANGE,'MAE = Σ|pᵢ − cᵢ| / n',
      ['Desviación absoluta media; la lectura más intuitiva: "el corpus difiere en promedio X fatalidades/año".',
       'No penaliza los extremos; siempre MAE ≤ RMSE. Una brecha grande entre ambos revela outliers.',
       'Se usa como criterio de tolerancia en tablas de proporciones (±5 pp).',
       'En este informe se expresa en fatalidades o en puntos porcentuales según el elemento.']),
     ('MAPE — Mean Absolute Percentage Error',RED,'MAPE = (100/n) · Σ|pᵢ − cᵢ| / |pᵢ|   (pᵢ ≠ 0)',
      ['Error relativo medio respecto del valor del paper; permite comparar elementos de distinta escala.',
       'Umbrales: ≤10% excelente · ≤20% bueno · ≤40% aceptable · >40% alto.',
       'Es la base de la calificación cuando n < 4 (p. ej. reparto Carbón/MNM con 2 categorías).',
       'Se infla cuando pᵢ es pequeño (categorías con 1-2 casos); se interpreta junto con MAE.']),
     ('Δ Total — Diferencia relativa de totales',GOLD,'Δ = (Σc − Σp) / Σp × 100%',
      ['Compara el universo total captado por el corpus frente al del paper en el mismo período.',
       'Δ ≈ 0 indica cobertura equivalente; Δ negativo grande indica criterio de inclusión más estrecho en el corpus (p. ej. CAEX).',
       'Complementa a r: dos series pueden tener r ≈ 1 y Δ = −50% (misma forma, distinta escala).',
       'En proporciones (%), Δ es 0 por construcción y se omite de la interpretación.'])]
    for i,(title,col,formula,bul) in enumerate(tests_info):
        r_,c_=divmod(i,3); x0=0.3+c_*3.5; y0=LH-0.85-r_*3.45
        rct(ax,x0,y0-3.3,3.3,3.3,facecolor=col,alpha=0.05,edgecolor=col,lw=0.8)
        rct(ax,x0,y0-0.38,3.3,0.38,facecolor=col,alpha=0.85)
        ax.text(x0+0.12,y0-0.19,title,fontsize=8.5,fontweight='bold',color='white',va='center')
        rct(ax,x0+0.08,y0-0.85,3.14,0.38,facecolor='white',edgecolor=col,lw=0.6)
        ax.text(x0+1.65,y0-0.66,formula,fontsize=7,color=col,fontweight='bold',ha='center',va='center',family='DejaVu Sans')
        yy=y0-1.0
        for b in bul:
            for j,l in enumerate(textwrap.wrap(b,64)):
                ax.text(x0+0.14 if j==0 else x0+0.3,yy,('• ' if j==0 else '')+l,fontsize=6.7,color='#333',va='top'); yy-=0.19
            yy-=0.06
    rct(ax,0.3,0.42,10.4,0.62,facecolor=LIGHT,edgecolor=NAVY,lw=0.7)
    ax.text(0.45,0.92,'Calificación global de cada elemento (base: Pearson r si n ≥ 4; MAPE si n < 4):',fontsize=7.8,fontweight='bold',color=NAVY)
    for i,(q,c) in enumerate([('EXCELENTE  r ≥ 0.95  |  MAPE ≤ 10%',TEAL),('BUENO  0.85 ≤ r < 0.95  |  MAPE ≤ 20%',NAVY),('ACEPTABLE  0.70 ≤ r < 0.85  |  MAPE ≤ 40%',GOLD),('PARCIAL  r < 0.70  |  MAPE > 40%',RED)]):
        x=0.45+i*2.55; rct(ax,x,0.5,2.42,0.34,facecolor=c,alpha=0.15,edgecolor=c,lw=0.7)
        ax.text(x+1.21,0.67,q,ha='center',va='center',fontsize=6.8,fontweight='bold',color=c)
    pdf.savefig(fig); plt.close(fig)

    # ================= 4. INVENTARIO =================
    fig,ax=blank_page(); header(ax,'Inventario de los 17 papers MSHA: 218 elementos, 36 reproducibles'); footer(ax,4)
    cols=[(0.3,'ID'),(0.75,'Autores y año'),(4.75,'Revista'),(6.6,'Período'),(7.45,'Tab.'),(7.9,'Fig.'),(8.35,'Total'),(8.9,'TOTAL'),(9.5,'PARC.'),(10.1,'NO')]
    y=LH-0.85; rh=0.33
    rct(ax,0.2,y-rh,LW-0.4,rh,facecolor=NAVY)
    for x,h in cols: ax.text(x,y-rh/2,h,fontsize=7.3,fontweight='bold',color='white',va='center')
    y-=rh
    for i,row in enumerate(INV):
        rct(ax,0.2,y-rh,LW-0.4,rh,facecolor=LIGHT if i%2==0 else 'white')
        for (x,_),v in zip(cols,row):
            ax.text(x,y-rh/2,textwrap.shorten(str(v),56) if isinstance(v,str) else str(v),fontsize=6.8,va='center',
                    color=TEAL if (x==8.9 and v) else DARK,fontweight='bold' if x==8.9 else 'normal')
        y-=rh
    rct(ax,0.2,y-rh,LW-0.4,rh,facecolor=GOLD,alpha=0.35)
    for (x,_),v in zip(cols,['','TOTAL 17 papers','','',92,126,218,36,35,28]):
        ax.text(x,y-rh/2,str(v),fontsize=7.3,fontweight='bold',va='center',color=DARK)
    y-=rh+0.15
    for l in ['TOTAL = reproducible directamente con el corpus (35 elementos → una página cada uno en este informe).  PARCIAL = reproducible solo para el subconjunto fatal (32).  NO = requiere MSHA injury DB, denominadores de horas (CPS/Employment DB) o texto íntegro de informes (23).',
              'Nota P16 (S478): 91 fatalidades haul truck 2005-2018 (NIOSH, bow-tie sobre informes finales); reproducibles Table 3 y Fig.2 → I-36 tras rasterizar (marcado 1*). Su codificación independiente con codebook es precedente directo del estudio Kappa del manuscrito. Nota: tres elementos TOTAL (P10 Fig.2, P10 Fig.4-5, P11 Fig.6-8) comparan estructura o proporciones porque el paper no publica la serie numérica; se documenta en la columna Procedencia de cada página.']:
        for j,ln in enumerate(textwrap.wrap(l,175)): ax.text(0.3,y,ln,fontsize=6.8,color='#444',va='top'); y-=0.19
        y-=0.06
    pdf.savefig(fig); plt.close(fig)

    # ================= 5..39 ITEMS =================
    for i,(it,pf,T,note) in enumerate(BUILT):
        item_page(pdf,FIRST_ITEM_PAGE+i,it,pf,T,note)

    # ================= RESUMEN =================
    pg=FIRST_ITEM_PAGE+35
    fig,ax=blank_page(); header(ax,'Resumen global de tests de similitud — 36 elementos'); footer(ax,pg)
    cols=[(0.3,'Nº'),(0.8,'Paper'),(2.75,'Elemento'),(6.05,'n'),(6.4,'r'),(6.95,'ρ'),(7.5,'RMSE'),(8.05,'MAE'),(8.6,'MAPE'),(9.2,'Δ Total'),(9.9,'Calif.')]
    y=LH-0.8; rh=0.171
    rct(ax,0.2,y-rh,LW-0.4,rh,facecolor=NAVY)
    for x,h in cols: ax.text(x,y-rh/2,h,fontsize=6.8,fontweight='bold',color='white',va='center')
    y-=rh; cnt=collections.Counter()
    for i,(it,pf,T,note) in enumerate(BUILT):
        cnt[T['qual']]+=1
        rct(ax,0.2,y-rh,LW-0.4,rh,facecolor=LIGHT if i%2==0 else 'white')
        vals=[it['code'],textwrap.shorten(it['paper'],36),textwrap.shorten(it['element'],44),str(T['n']),
              '%.3f'%T['r'] if T['r'] is not None else 'n/a','%.3f'%T['rho'] if T['rho'] is not None else 'n/a',
              '%.2f'%T['rmse'],'%.2f'%T['mae'],'%.1f%%'%T['mape'],'%+.1f%%'%T['delta'] if T['delta']==T['delta'] else 'n/a',T['qual']]
        for (x,_),v in zip(cols,vals):
            ax.text(x,y-rh/2,v,fontsize=6.0,va='center',color=T['qcol'] if v==qual_ix else DARK,fontweight='bold' if v==qual_ix else 'normal')
        y-=rh
    y-=0.08
    rct(ax,0.2,y-0.42,LW-0.4,0.42,facecolor=LIGHT,edgecolor=NAVY,lw=0.7)
    tot=sum(cnt.values())
    ax.text(0.35,y-0.21,'Distribución de calificaciones (36 elementos):',fontsize=7.5,fontweight='bold',color=NAVY,va='center')
    for i,(q,c) in enumerate([('EXCELENTE',TEAL),('BUENO',NAVY),('ACEPTABLE',GOLD),('PARCIAL',RED),('DIVERGENCIA DOC.','#6B4E9B')]):
        x=3.35+i*1.52; rct(ax,x,y-0.36,1.42,0.3,facecolor=c,alpha=0.15,edgecolor=c,lw=0.7)
        ax.text(x+0.71,y-0.21,'%s: %d (%.0f%%)'%(q.replace(' DOC.',''),cnt[q],cnt[q]/tot*100),ha='center',va='center',fontsize=6.2,fontweight='bold',color=c)
    pdf.savefig(fig); plt.close(fig)
    SUMMARY_CNT=cnt

    # ================= EVOLUCIÓN DE LA VALIDACIÓN =================
    fig,ax=blank_page(); header(ax,'Evolución de la validación — S411 → S535 (89 sesiones, 05-sep-2026)'); footer(ax,pg)
    filas=[('S411','Línea base: 21/35 ACEPT+ · 14 PARCIAL sin diagnóstico · 0 elementos sobre evidencia primaria'),
     ('S412-S422','Depuración estructural: join Part 50, 114 Mine IDs, 9 duplicados, balance anual EXACTO 2000-2026'),
     ('S424-S429','Criterio dual de equipo + índices FABM98/FABC99 → primera excelencia nueva (I-24, r=0.982)'),
     ('S430-S438','FASE A (17 PDFs): tablas y figuras EXACTAS reemplazan digitalizaciones; 5 figuras-fantasma desenmascaradas; nace DIVERGENCIA DOCUMENTADA'),
     ('S441-S449','~1,160 informes finales ingeridos (RARs 1995-2026): 850 celdas oficiales, quinquenio 95-99 en verde, Fort Knox sellado'),
     ('S455-S459','Análisis dirigido por años → re-extracción por contexto → +2 EXC · techo triple-probado de I-01'),
     ('S462-S465','FUSIÓN certificada con capa de sesgos (275 col): match por ID, clave canónica año+mes+nº, cuarentena 0'),
     ('S471-S473','Técnica CENSAL: I-15 (0.965), I-17 (MAPE 2.0), I-09 (r=1.000) · nace I-36 EXCELENTE (0.955) · 36 elementos'),
     ('S476','Patrón experto de Reardon parseado por caso: acuerdo 52.6%% vs diccionario = justificación EMPÍRICA del Kappa IRR'),
     ('S478-S478','Forma final: 17 EXC · 5 divergencias probadas · 3 parciales-techo · cada elemento con su causa escrita')]
    y=LH-0.85
    for tag,txt_ in filas:
        rct(ax,0.3,y-0.5,1.5,0.44,facecolor=NAVY); ax.text(1.05,y-0.28,tag,ha='center',va='center',fontsize=7.2,color='white',fontweight='bold')
        import textwrap as _tw
        for j,l in enumerate(_tw.wrap(txt_,150)[:2]):
            ax.text(2.0,y-0.18-j*0.17,l,fontsize=6.6,va='center',color=DARK)
        y-=0.56
    for _j,_l in enumerate(textwrap.wrap('Lectura: el conteo de EXCELENTES pasó de 11 nominales a 17 verificados; los 14 PARCIAL opacos se convirtieron en 3 techos demostrados y 5 divergencias con evidencia primaria — cero elementos sin explicación.',150)):
        ax.text(0.3,y-0.2-_j*0.17,_l,fontsize=6.8,color=NAVY,fontweight='bold')
    pdf.savefig(fig); plt.close(fig); pg+=1

    # ================= CONCLUSIONES =================
    fig,ax=blank_page(); header(ax,'Conclusiones — Validez del corpus FatalityCheck S535 frente a la literatura MSHA'); footer(ax,pg+1)
    exc_ok=cnt['EXCELENTE']+cnt['BUENO']
    def codes(q): return ', '.join(it['code'] for it,pf,T,n in BUILT if T['qual']==q)
    off=[it['code'] for it,pf,T,n in BUILT if it['prov']=='OFICIAL']
    blocks=[
     ('1. Cobertura del universo de fatalidades (elementos con cifras oficiales MSHA)',TEAL,
      'Los %d elementos comparados contra cifras oficiales MSHA (%s) obtienen r ≥ 0.98 y Δ Total dentro de ±3%%. El corpus S535 reproduce el numerador de cualquier tasa publicada entre 1995 y 2023, incluidos los eventos múltiples (Sago 2006, Upper Big Branch 2010). Esta es la validación externa más fuerte del informe.'%(len(off),', '.join(off))),
     ('2. Balance de calificaciones',NAVY,
      'EXCELENTE (%d): %s.  BUENO (%d): %s.  ACEPTABLE (%d): %s.  PARCIAL (%d): %s.  %d de 35 elementos (%.0f%%) alcanzan ACEPTABLE o superior.'%(
        cnt['EXCELENTE'],codes('EXCELENTE'),cnt['BUENO'],codes('BUENO'),cnt['ACEPTABLE'],codes('ACEPTABLE'),cnt['PARCIAL'],codes('PARCIAL'),35-cnt['PARCIAL'],(35-cnt['PARCIAL'])/35*100)),
     ('3. Diferencias metodológicas documentadas (no errores de cobertura)',GOLD,
      'Equipo: los papers cuentan el equipo operado por la víctima; S535 asigna el equipo primario del accidente (incluye mantenimiento y tránsito), (I-02/06/08). Desde S424 el informe reproduce ADEMÁS el criterio del paper (equipo operado, OCCUPATION oficial) en la familia afectada, y el campo MINING_EQUIP oficial respalda la atribución del corpus: diferencia metodológica certificada, no brecha.'),
     ('4. Brechas de completitud detectadas por este ejercicio',RED,
      'Las tres brechas de completitud detectadas en S411 fueron CERRADAS mediante el join oficial con el dataset MSHA Part 50 Accidents (S417-S419): (a) condición de contratista: 71.8%% del corpus con dato OFICIAL (20.9%% de contratistas en 1998-2007; la diferencia restante frente al ~30%% publicado es de criterio del paper, no de captura); (b) mantenimiento: ventana y conteo EXACTOS de Reardon (Tablas A1/A2: 174 casos 2002-2011; cobertura censal del corpus 89.7%%, Δ=-1.1%%); (c) ámbito OFICIAL (SUBUNIT) 2000-2026 con 5 N/D. Límite residual: 1995-1999 (índices FABC/FABM en curso).'),
     ('5. Valor diferencial para el manuscrito',PURPLE,
      'Ningún paper supera 24 años de serie ni declara validación estadística de su dataset; FatalityCheck S535 aporta 32 años, 275 campos, validación r=0.970 vs Part 50 y la capa de sesgos cognitivos MAP-v1. Los 35 elementos reproducidos, con sus tests y sus brechas explícitas, constituyen la evidencia de validez externa y de transparencia metodológica exigible para Safety Science / Journal of Safety Research.')]
    y=LH-0.9
    for t,c,body in blocks:
        lines=textwrap.wrap(body,196); h=0.30+0.165*len(lines)
        rct(ax,0.3,y-h,LW-0.6,h,facecolor=c,alpha=0.06,edgecolor=c,lw=0.7); rct(ax,0.3,y-h,0.09,h,facecolor=c)
        ax.text(0.55,y-0.1,t,fontsize=8.8,fontweight='bold',color=c,va='top')
        for j,l in enumerate(lines): ax.text(0.55,y-0.34-j*0.18,l,fontsize=6.9,color='#333',va='top')
        y-=h+0.12
    ax.text(LW/2,0.55,'Documento generado íntegramente desde FatalityCheck S535 (corpus_for_papers.xlsx, 1,654 registros activos) · script: build.py S536 · 05-sep-2026',ha='center',fontsize=6.8,color=GRAY,style='italic')
    pdf.savefig(fig); plt.close(fig)

    d=pdf.infodict(); d['Title']='Informe Comparativo Papers MSHA vs FatalityCheck S535 — 36 elementos'; d['Author']='Invictum SPA'

from pypdf import PdfReader
import os
print('PDF: %d KB · %d páginas'%(os.path.getsize(OUT)//1024,len(PdfReader(OUT).pages)))
print(dict(SUMMARY_CNT))
