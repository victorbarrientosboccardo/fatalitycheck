import importlib, sys, shutil, io, contextlib
sys.path.insert(0,'.')
def run(corpus_path):
    shutil.copy(corpus_path,'/home/claude/corpus_for_papers.xlsx')
    for m in ['lib','items']:
        if m in sys.modules: del sys.modules[m]
    with contextlib.redirect_stdout(io.StringIO()):
        import lib, items
        res={}
        for it in items.ITEMS:
            try:
                pf,T,interp,note=it['builder']()
                res[it['code']]=(T['qual'],T.get('r'),T.get('mape'))
            except Exception as e:
                res[it['code']]=('ERROR',str(e)[:40],None)
    return res
old=run('/home/claude/corpus_maestro.xlsx')      # S495
new=run('/home/claude/corpus_S500.xlsx')          # S500
print("%-6s %-16s %-16s %s"%("Elem","S495","S500","Δ"))
cambios=0
for k in sorted(old):
    o,n=old[k],new[k]
    ch = o[0]!=n[0] or (o[1] is not None and n[1] is not None and abs(o[1]-n[1])>1e-9)
    if ch:
        cambios+=1
        print("%-6s %-16s %-16s r: %s → %s"%(k,o[0],n[0],
              ('%.4f'%o[1]) if isinstance(o[1],float) else o[1],
              ('%.4f'%n[1]) if isinstance(n[1],float) else n[1]))
print("\nElementos con cambio:",cambios,"de",len(old))
from collections import Counter
print("Distribución S500:",dict(Counter(v[0] for v in new.values())))
