# -*- coding: utf-8 -*-
import openpyxl, collections, re, textwrap
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.lines import Line2D
import numpy as np
from scipy import stats as sp

NAVY='#1F3864'; GOLD='#B08D57'; GRAY='#666666'; RED='#C0392B'; TEAL='#1A7A6E'
PURPLE='#6C3483'; ORANGE='#CA6F1E'; LIGHT='#F0F4F8'; DARK='#222222'
PC=GOLD; CC=NAVY
LW,LH=11.0,8.5
DB_TAG='FatalityCheck S535 · 1,654 registros · 1995-2026'

plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.titlesize':9,
    'axes.titleweight':'bold','axes.spines.top':False,'axes.spines.right':False,
    'axes.labelsize':7.5,'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7})

# ---------------- corpus ----------------
wb=openpyxl.load_workbook('/home/claude/corpus_for_papers.xlsx',read_only=True,data_only=True)
ws=wb['Corpus completo']
DATA=[]
for row in ws.iter_rows(min_row=2,values_only=True):
    rid=str(row[0] or '')
    if rid[:3] not in ('CAI','MAI','FAI','CAL','MAL'): continue
    if 'ANULADO' in rid.upper(): continue
    if 'SUPERSEDED' in str(row[62] or '').upper(): continue
    DATA.append(row)

def yr(r):
    try: return int(str(r[2]).split('.')[0])
    except: return None
def coal(r): return 'carb' in str(r[4] or '').lower()
def st(r): return str(r[7] or '').strip()
def txt(r,c): return str(r[c] or '').lower() if c < len(r) else ''
def has(r,cols,kws):
    return any(any(k in txt(r,c) for k in kws) for c in cols)
def sel(y1,y2,f=lambda r:True): return [r for r in DATA if yr(r) and y1<=yr(r)<=y2 and f(r)]
def byyear(rows,y1,y2):
    c=collections.Counter(yr(r) for r in rows); return [c.get(y,0) for y in range(y1,y2+1)]

def tipo(r):
    t=txt(r,5)
    if 'acarreo' in t: return 'Powered haulage'
    if 'maquinaria' in t or 'atrapamiento' in t: return 'Machinery'
    if 'caída de persona' in t or 'caida de persona' in t: return 'Fall of person'
    if 'techo' in t or 'costilla' in t or 'highwall' in t or 'caja' in t: return 'Fall of ground'
    if 'electro' in t or 'léctri' in t: return 'Electrical'
    if 'explosi' in t or 'detonador' in t or 'tronadura' in t: return 'Explosion'
    return 'Other'

def _eqmap(e):
    if 'caex' in e or 'haul truck' in e or 'ore haulage' in e or 'camión de acarreo' in e or 'haulage truck' in e or 'off-highway' in e or 'dump truck' in e: return 'Haul truck'
    if 'correa' in e or 'conveyor' in e: return 'Belt conveyor'
    if 'cargador' in e or 'front-end' in e: return 'Front-end loader'
    if 'bulldozer' in e or 'topadora' in e or 'dozer' in e: return 'Dozer'
    if 'continuous' in e: return 'Continuous miner'
    if 'roof bolter' in e: return 'Roof bolter'
    if 'shuttle' in e: return 'Shuttle car'
    if 'longwall' in e: return 'Longwall'
    if 'huinche' in e or 'winch' in e or 'hoist' in e: return 'Hoisting'
    if 'grúa' in e or 'crane' in e: return 'Crane'
    if 'pala' in e or 'excavat' in e or 'shovel' in e: return 'Excavator/Shovel'
    if 'scoop' in e or 'lhd' in e: return 'LHD/Scoop'
    return None
def equipo(r):
    e58=txt(r,58)
    if e58 and 'no value' not in e58:
        m=_eqmap(e58)
        if m: return m
    m=_eqmap(txt(r,86))
    if m: return m
    m=_eqmap(txt(r,74))
    if m: return m
    return 'Other'
OCC2EQ=[('Haul truck',['truck driver','ore truck','haulage truck','large haul','camion de acarreo','camión de acarreo','conductor de cami','operador de cami','caex']),
 ('Belt conveyor',['beltman','belt man','conveyor operator','correa']),
 ('Front-end loader',['front-end loader','front end loader','loader operator','end loader','cargador frontal','operador de cargador']),
 ('Dozer',['dozer','bulldozer','topadora']),
 ('Continuous miner',['continuous miner','coal mole','minero continuo']),
 ('Roof bolter',['roof bolter','rock bolter','pinner','apernador','empernador','perforador de techo']),
 ('Shuttle car',['shuttle car']),
 ('Longwall',['longwall']),
 ('Hoisting',['hoistman','hoist operator','huinchero']),
 ('Crane',['crane operator','grua','grúa']),
 ('Excavator/Shovel',['shovel operator','excavator','dragline','backhoe','operador de pala']),
 ('LHD/Scoop',['scoop','lhd','load haul dump'])]
_EXCL_TRUCK=['fuel','water','lube','service truck','fire truck','forklift','grease']
MECH_KW=('haulage','machinery','maquinaria','acarreo','electrical','eléctric','hoisting','izaje','conveyor','correa','exploding vessel','atrapamiento','caught in','struck by machine','vuelco','overturn','atropell','run over')
def mech_equip(r):
    t=(txt(r,5)+' '+txt(r,11)).lower()
    return any(k in t for k in MECH_KW)
def equipo_op(r):
    _v=_equipo_op_base(r)
    if _v: return _v
    try:
        import datetime as _dt
        d=r[3]
        if isinstance(d,_dt.datetime) and d.year<2000:
            c=str(r[86] or '')
            if 'contexto' in c or 'OFICIAL-informe' in c:
                return c.split(' (')[0]
    except Exception: pass
    return _v
def _equipo_op_base(r):
    for c in (87,8):
        t=txt(r,c)
        if not t or t.startswith('n/d'): continue
        for eq,kws in OCC2EQ:
            if any(k in t for k in kws):
                if eq=='Haul truck' and any(x in t for x in _EXCL_TRUCK): break
                return eq
    return None
def eq_pct_op(rows,order):
    import collections as _c
    cnt=_c.Counter(equipo_op(r) for r in rows); n=max(1,len(rows))
    known=[k for k in order if k!='Other']; oth=n-sum(cnt.get(k,0) for k in known)
    return [cnt.get(k,0)/n*100 if k!='Other' else oth/n*100 for k in order]
def _equipo_old(r):
    e=txt(r,58)+' '+txt(r,74)
    if 'caex' in e or 'haul truck' in e or 'ore haulage' in e: return 'Haul truck'
    if 'correa' in e or 'conveyor' in e: return 'Belt conveyor'
    if 'cargador' in e or 'front-end' in e: return 'Front-end loader'
    if 'bulldozer' in e or 'topadora' in e or 'dozer' in e: return 'Dozer'
    if 'continuous' in e: return 'Continuous miner'
    if 'roof bolter' in e: return 'Roof bolter'
    if 'shuttle' in e: return 'Shuttle car'
    if 'longwall' in e: return 'Longwall'
    if 'huinche' in e or 'winch' in e or 'hoist' in e: return 'Hoisting'
    if 'grúa' in e or 'crane' in e: return 'Crane'
    if 'pala' in e or 'excavat' in e or 'shovel' in e: return 'Excavator/Shovel'
    if 'scoop' in e or 'lhd' in e: return 'LHD/Scoop'
    return 'Other'

UG_KW=['subterr','underground','mina subterránea']
def ug(r):
    c=str(r[84] or '')
    if c.startswith('UG'): return True
    if c.startswith(('Surface','Planta','Sf')): return False
    if has(r,[6,12,36,11,20],UG_KW): return True
    t=txt(r,5); e=equipo(r)
    if 'techo' in t or 'costilla' in t or 'caja' in t: return True
    if e in ('Continuous miner','Roof bolter','Shuttle car','Longwall','LHD/Scoop'): return True
    if 'explosi' in t and coal(r): return True
    return False
def contractor(r):
    c=str(r[83] or '')
    if c.startswith('S'): return True
    if c.startswith('N') and 'N/D' not in c[:3]: return False
    return has(r,[6,8,1,12],['contratista','contractor'])
def maint(r):
    if str(r[85] or '').startswith('maint'): return True
    return has(r,[20,42,53,51],['manten','mantenc','maint','repair','repara'])
def age(r):
    try: return float(str(r[9]).split()[0])
    except: return None
def exp(r):
    m=re.search(r'(\d+\.?\d*)',str(r[13] or ''))
    return float(m.group(1)) if m else None

EAST={'WV','KY','VA','PA','AL','TN','OH','MD','NC','SC','GA','FL','NY','NJ','ME','NH','VT','MA','CT','RI','DE'}
MIDW={'IL','IN','MI','WI','MN','IA','MO','ND','SD','NE','KS','OK','AR','LA','MS','TX'}
def region(r):
    s=st(r)
    if s in EAST: return 'East'
    if s in MIDW: return 'Midwest'
    return 'West' if s else 'N/D'

def shift(r):
    t=txt(r,22)
    if 'mañ' in t or 'día' in t or 'dia' in t or 'day' in t: return 'Día'
    if 'tarde' in t: return 'Tarde'
    if 'noche' in t: return 'Noche'
    return 'N/D'

# MSHA official annual fatalities (DOL press releases / MSHA Fact Sheets)
MSHA_COAL={1995:47,1996:39,1997:30,1998:29,1999:35,2000:38,2001:42,2002:27,2003:30,2004:28,
 2005:22,2006:47,2007:34,2008:30,2009:18,2010:48,2011:21,2012:20,2013:20,2014:16,2015:12,
 2016:9,2017:15,2018:12,2019:12,2020:5,2021:11,2022:9,2023:10}
MSHA_MNM={1995:53,1996:47,1997:61,1998:52,1999:56,2000:47,2001:30,2002:42,2003:26,2004:27,
 2005:35,2006:26,2007:33,2008:23,2009:17,2010:24,2011:16,2012:16,2013:22,2014:30,2015:17,
 2016:17,2017:13,2018:16,2019:13,2020:24,2021:26,2022:21,2023:30}
def msha_tot(y1,y2): return [MSHA_COAL[y]+MSHA_MNM[y] for y in range(y1,y2+1)]

# ---------------- similarity tests ----------------
DIVERGENTES={'I-13':'constructo: peligros distintos (paper) vs subtipos de accidente (corpus)',
 'I-30':'constructo: categorías narrativas 1990-2002 del paper vs mecanismo del corpus (solape 95-02)',
 'I-32':'constructo: Figure 9 exacta confirma poblaciones/categorías no equivalentes',
 'I-01':'constructo TRIPLE-PROBADO (S459): tres operacionalizaciones del universo equipment-related de Kecojevic medidas (r=0.595/0.595/0.506) — su codificación manual (Miscellaneous=172 residual) no es reproducible algorítmicamente; la FORMA anual correlaciona, el nivel diverge por criterio',
 'I-23':'constructo: Karra 2005 es un modelo de TASAS (Poisson/NB, 1983-2002, denominador horas-empleo) — sus 4 figuras reales son plots de regresión; las "Figs 6-8" de serie anual no existen en el paper. El corpus (numeradores fatales) no puede reproducir tasas por diseño; el punto de contacto verificable —nivel de contratistas— calza: 20.6% corpus vs 19-26% paper (S443)'}
def aplicar_divergencia(code,T):
    if code in DIVERGENTES:
        T['qual']='DIVERGENCIA DOC.'; T['qcol']='#6B4E9B'; T['div_nota']=DIVERGENTES[code]
    return T
def tests(pv,cv):
    p=np.array(pv,float); c=np.array(cv,float); n=len(p)
    out=dict(n=n,sump=float(p.sum()),sumc=float(c.sum()))
    out['rmse']=float(np.sqrt(np.mean((p-c)**2)))
    out['mae']=float(np.mean(np.abs(p-c)))
    mask=p!=0
    out['mape']=float(np.mean(np.abs((p[mask]-c[mask])/p[mask]))*100) if mask.any() else float('nan')
    out['delta']=float((c.sum()-p.sum())/p.sum()*100) if p.sum() else float('nan')
    if n>=4 and np.std(p)>0 and np.std(c)>0:
        r,pr=sp.pearsonr(p,c); rho,prho=sp.spearmanr(p,c)
        out.update(r=float(r),pr=float(pr),rho=float(rho),prho=float(prho))
        if r>=0.95: q='EXCELENTE'
        elif r>=0.85: q='BUENO'
        elif r>=0.70: q='ACEPTABLE'
        else: q='PARCIAL'
        out['base']='Pearson r'
    else:
        out.update(r=None,pr=None,rho=None,prho=None)
        m=out['mape']
        q='EXCELENTE' if m<=10 else 'BUENO' if m<=20 else 'ACEPTABLE' if m<=40 else 'PARCIAL'
        out['base']='MAPE (n<4)'
    out['qual']=q
    out['qcol']={'EXCELENTE':TEAL,'BUENO':NAVY,'ACEPTABLE':GOLD,'PARCIAL':RED}[q]
    return out

def fp(p):
    if p is None: return '—'
    return 'p<0.001' if p<0.001 else 'p=%.3f'%p

# ---------------- plotting helpers ----------------

from matplotlib.textpath import TextPath
def wrapw(txt,fs,maxw_in):
    """Envuelve midiendo el ancho real renderizado de cada línea (pulgadas)."""
    out=[]
    for w in txt.split():
        if out and TextPath((0,0),out[-1]+' '+w,size=fs).get_extents().width/72.0<=maxw_in:
            out[-1]+=' '+w
        else:
            out.append(w)
    return out

def dline(ax,xs,pv,cv,title,yl='Fatalidades',plab='Paper',clab='S535'):
    ax.plot(xs,pv,'o-',color=PC,lw=1.8,ms=4,label='%s (Σ=%d)'%(plab,round(sum(pv))))
    ax.plot(xs,cv,'s--',color=CC,lw=1.8,ms=4,label='%s (Σ=%d)'%(clab,round(sum(cv))))
    ax.set_ylabel(yl); ax.set_title(title if len(title)<=95 else title[:92]+'…',fontsize=8.3,fontweight='bold')
    ax.set_xticks(xs); ax.set_xticklabels([str(x) for x in xs],rotation=45)
    ax.legend(fontsize=7.5); ax.grid(axis='y',alpha=0.2)
    ax.set_ylim(0,max(max(pv),max(cv))*1.15)

def dbar(ax,cats,pv,cv,title,yl='Fatalidades',pct=False,rot=25):
    x=np.arange(len(cats)); w=0.38
    b1=ax.bar(x-w/2,pv,w,color=PC,alpha=0.9,label='Paper')
    b2=ax.bar(x+w/2,cv,w,color=CC,alpha=0.9,label='S535')
    top=max(max(pv),max(cv))
    for b,v in zip(b1,pv):
        ax.text(b.get_x()+b.get_width()/2,v+top*0.01,('%.1f%%'%v) if pct else str(int(round(v))),
                ha='center',va='bottom',fontsize=6.3,color=PC,fontweight='bold')
    for b,v,pvv in zip(b2,cv,pv):
        dy = top*0.055 if abs(v-pvv)<top*0.06 else top*0.01  # escalona la etiqueta S535 si choca con la del paper
        ax.text(b.get_x()+b.get_width()/2,v+dy,('%.1f%%'%v) if pct else str(int(round(v))),
                ha='center',va='bottom',fontsize=6.3,color=CC,fontweight='bold')
    ax.set_xticks(x); ax.set_xticklabels(cats,rotation=rot,ha='right' if rot else 'center',fontsize=7)
    ax.set_ylabel(yl); ax.set_title(title if len(title)<=95 else title[:92]+'…',fontsize=8.3,fontweight='bold')
    ax.legend(fontsize=7.5); ax.grid(axis='y',alpha=0.2); ax.set_ylim(0,top*1.22)

def hbar(ax,cats,pv,cv,title,xl='%'):
    import textwrap as _tw
    cats=['\n'.join(_tw.wrap(str(c),14)[:3]) for c in cats]
    y=np.arange(len(cats)); h=0.38
    ax.barh(y+h/2,pv,h,color=PC,alpha=0.9,label='Paper')
    ax.barh(y-h/2,cv,h,color=CC,alpha=0.9,label='S535')
    top=max(max(pv),max(cv))
    ax.set_xlim(0, top*1.16)
    for yi,(a,b) in enumerate(zip(pv,cv)):
        for val,yy,col in ((a,yi+h/2,PC),(b,yi-h/2,CC)):
            if val>top*0.88: ax.text(val-top*0.015,yy,'%.1f'%val,va='center',ha='right',fontsize=6.2,color='white',fontweight='bold')
            else: ax.text(val+top*0.012,yy,'%.1f'%val,va='center',fontsize=6.2,color=col,fontweight='bold')
    ax.set_yticks(y); ax.set_yticklabels(cats,fontsize=5.8); ax.invert_yaxis()
    ax.set_xlabel(xl); ax.set_title(title if len(title)<=95 else title[:92]+'…',fontsize=8.3,fontweight='bold')
    ax.legend(fontsize=7.5,loc='lower right'); ax.grid(axis='x',alpha=0.2); ax.set_xlim(0,top*1.18)

def rct(ax,x,y,w,h,**kw):
    ax.add_patch(mpatches.FancyBboxPatch((x,y),w,h,boxstyle='square,pad=0',**kw))

def blank_page():
    fig=plt.figure(figsize=(LW,LH))
    ax=fig.add_axes([0,0,1,1]); ax.set_axis_off(); ax.set_xlim(0,LW); ax.set_ylim(0,LH)
    return fig,ax

def header(ax,title,right=DB_TAG,sub=''):
    rct(ax,0,LH-0.62,LW,0.62,facecolor=NAVY)
    ax.text(0.3,LH-0.27,title,color='white',fontsize=12,fontweight='bold',va='center')
    ax.text(LW-0.3,LH-0.2,right,color=GOLD,fontsize=7.5,va='center',ha='right')
    if sub: ax.text(LW-0.3,LH-0.45,sub,color='#C8D0E0',fontsize=7.5,va='center',ha='right')

def footer(ax,pageno):
    rct(ax,0,0,LW,0.32,facecolor=LIGHT)
    ax.text(0.3,0.16,'Informe Comparativo Papers MSHA vs FatalityCheck S535 · Invictum SPA · Copiapó, Chile · 05-sep-2026',
            fontsize=7,color=GRAY,va='center')
    ax.text(LW-0.3,0.16,'Página %d'%pageno,fontsize=7,color=GRAY,va='center',ha='right')

PROV_DESC={'OFICIAL':'Cifras oficiales MSHA (mismas que usa el paper)',
           'TABLA':'Valores tomados de tabla del paper',
           'DIGITALIZADO':'Valores leídos de la figura del paper (±1 unidad)',
           'TEXTO':'Valor(es) puntual(es) citados en el texto del paper',
           'CATEGÓRICO':'Comparación de categorías / proporciones reportadas',
 'TABLA (PDF)':'Valores exactos extraídos de la tabla del PDF del paper (verificado S478)'}

def item_page(pdf,pageno,item,plotfn,T,pv_note):
    """item: dict(code,paper,ref,period,element,desc,prov,interp)"""
    fig,ax=blank_page()
    header(ax,'%s — %s'%(item['code'],item['element']),sub='%s · Período %s'%(item['paper'],item['period']))
    footer(ax,pageno)
    # left figure
    axf=fig.add_axes([0.16,0.13,0.43,0.72] if item.get('hb') else [0.045,0.13,0.545,0.72])
    plotfn(axf)
    # caption
    cap=textwrap.fill('Fuente paper: %s. %s'%(item['ref'],item['desc']),100)
    ax.text(0.5,0.72,cap,fontsize=6.8,color='#444',style='italic',va='top')
    # right panel
    X0=6.75; W=3.95
    rct(ax,X0,LH-1.62,W,0.9,facecolor=NAVY)
    ax.text(X0+W/2,LH-1.0,'TESTS DE SIMILITUD',ha='center',va='center',fontsize=10,fontweight='bold',color='white')
    ax.text(X0+W/2,LH-1.38,'FatalityCheck S535  vs  %s'%item['paper'].split('(')[0].strip(),ha='center',va='center',fontsize=7.5,color=GOLD)
    # provenance
    rct(ax,X0,LH-2.28,W,0.58,facecolor=GOLD,alpha=0.15)
    ax.text(X0+0.1,LH-1.85,'Procedencia valores paper: %s'%item['prov'],fontsize=7.5,fontweight='bold',color='#7A5C2E')
    for j,l in enumerate(textwrap.wrap(PROV_DESC[item['prov']]+'. '+pv_note,90)[:3]):
        ax.text(X0+0.1,LH-2.00-j*0.145,l,fontsize=5.9,color='#444',va='center')
    # qualification
    rct(ax,X0,LH-2.85,W,0.5,facecolor=T['qcol'],alpha=0.16)
    base=('r=%.3f'%T['r']) if T['r'] is not None else ('MAPE=%.1f%%'%T['mape'])
    ax.text(X0+W/2,LH-2.6,'Calificación: %s   (%s)'%(T['qual'],base),ha='center',va='center',
            fontsize=10,fontweight='bold',color=T['qcol'])
    # table
    rows=[('Pearson r','%.4f'%T['r'] if T['r'] is not None else 'n/a (n<4)',fp(T['pr']),'Correlación lineal'),
          ('Spearman ρ','%.4f'%T['rho'] if T['rho'] is not None else 'n/a (n<4)',fp(T['prho']),'Correlación de rangos'),
          ('RMSE','%.3f'%T['rmse'],'—','Error cuadrático medio'),
          ('MAE','%.3f'%T['mae'],'—','Error absoluto medio'),
          ('MAPE','%.2f%%'%T['mape'],'—','Error porcentual medio'),
          ('Δ Total','%+.2f%%'%T['delta'] if T['delta']==T['delta'] else 'n/a','—','Σ Paper=%.0f · Σ S535=%.0f'%(T['sump'],T['sumc'])),
          ('n','%d'%T['n'],'—','Puntos comparados')]
    y=LH-3.05; rh=0.34
    rct(ax,X0,y-rh,W,rh,facecolor=NAVY)
    for h,dx in zip(['Test','Valor','p','Descripción'],[0.1,1.05,2.0,2.7]):
        ax.text(X0+dx,y-rh/2,h,fontsize=7.2,fontweight='bold',color='white',va='center')
    y-=rh
    for i,row in enumerate(rows):
        rct(ax,X0,y-rh,W,rh,facecolor=LIGHT if i%2==0 else 'white')
        ax.text(X0+0.1,y-rh/2,row[0],fontsize=7,fontweight='bold',color=DARK,va='center')
        col=DARK
        if i==0 and T['r'] is not None: col=T['qcol']
        ax.text(X0+1.05,y-rh/2,row[1],fontsize=7.5,fontweight='bold',color=col,va='center')
        ax.text(X0+2.0,y-rh/2,row[2],fontsize=6.8,color='#666',va='center')
        ax.text(X0+2.7,y-rh/2,row[3],fontsize=6.0 if i==5 else 6.6,color='#444',va='center')
        y-=rh
    # interpretation
    y-=0.12
    lines=wrapw(item['interp'],6.0,W-0.42)
    fs_i, lh = 6.0, 0.165
    if len(lines)>13:  # texto muy largo: compactar tipografía en vez de truncar
        fs_i, lh = 5.6, 0.150; lines=wrapw(item['interp'],5.6,W-0.42)
    lines=lines[:16]
    hbox=0.3+lh*len(lines)
    rct(ax,X0,y-hbox,W,hbox,facecolor='#EBF5FB')
    rct(ax,X0,y-hbox,0.08,hbox,facecolor=NAVY)
    ax.text(X0+0.18,y-0.1,'Interpretación',fontsize=7.8,fontweight='bold',color=NAVY,va='top')
    for j,l in enumerate(lines):
        ax.text(X0+0.18,y-0.28-j*lh,l,fontsize=fs_i,color='#333',va='top')
    # global legend
    fig.legend(handles=[Line2D([0],[0],color=PC,lw=2,marker='o',ms=5,label='Paper publicado'),
                        Line2D([0],[0],color=CC,lw=2,marker='s',ms=5,label='FatalityCheck S535')],
               loc='upper left',bbox_to_anchor=(0.045,0.905),ncol=2,fontsize=7.5,framealpha=0.9)
    pdf.savefig(fig); plt.close(fig)

def lead(cats,vals):
    return cats[int(np.argmax(vals))]
def dirw(delta):
    return ('más' if delta>0 else 'menos')
def rank_txt(T):
    if T['rho'] is None: return ''
    if T['rho']>=0.85: return 'el ordenamiento de categorías coincide (ρ=%.3f)'%T['rho']
    if T['rho']>=0.6: return 'el ordenamiento coincide parcialmente (ρ=%.3f)'%T['rho']
    return 'el ordenamiento difiere (ρ=%.3f)'%T['rho']
def trend_txt(T):
    if T['r'] is None: return ''
    if T['r']>=0.9: return 'la forma temporal coincide (r=%.3f)'%T['r']
    if T['r']>=0.7: return 'la tendencia general coincide (r=%.3f)'%T['r']
    return 'la serie anual difiere (r=%.3f)'%T['r']

def dline2(ax,years,p1,c1,p2,c2,title):
    ax.plot(years,p1,'-o',color=PC,ms=3,lw=1.4,label='Loader paper'); ax.plot(years,c1,'--s',color=PC,ms=3,lw=1.1,alpha=0.55,label='Loader S535')
    ax.plot(years,p2,'-o',color=CC,ms=3,lw=1.4,label='Truck paper'); ax.plot(years,c2,'--s',color=CC,ms=3,lw=1.1,alpha=0.55,label='Truck S535')
    ax.set_title(title if len(title)<=95 else title[:92]+'…',fontsize=8.3,fontweight='bold'); ax.legend(fontsize=5.6,ncol=2); ax.grid(alpha=0.25); ax.margins(x=0.03)
