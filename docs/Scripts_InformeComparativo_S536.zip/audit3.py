import matplotlib
matplotlib.use('Agg')
from matplotlib.backends.backend_pdf import PdfPages
_orig = PdfPages.savefig
PAGE=[0]; ISSUES=[]
LW,LH=11.0,8.5
def audit_savefig(self, fig, **kw):
    PAGE[0]+=1; pg=PAGE[0]
    fig.canvas.draw(); ren=fig.canvas.get_renderer(); inv=fig.dpi_scale_trans.inverted()
    boxes=[]
    for ax in fig.axes:
        for t in ax.texts:
            s=t.get_text().strip()
            if not s: continue
            bi=t.get_window_extent(renderer=ren).transformed(inv)
            if bi.x1>LW-0.02 or bi.y1>LH-0.0 or bi.x0<0 or bi.y0<0:
                ISSUES.append((pg,'FUERA-PAG',round(bi.x1,2),s[:55]))
            boxes.append((bi,s))
            if 5<=pg<=40 and bi.x0>=6.6 and bi.y0<0.55 and not s.startswith('Página') and 'Invictum' not in s:
                ISSUES.append((pg,'BAJO-PIE',round(bi.y0,2),s[:55]))
    # colisiones texto-texto (solapamiento real > 0.03 in en ambos ejes)
    for i in range(len(boxes)):
        for j in range(i+1,len(boxes)):
            a,sa=boxes[i]; b,sb=boxes[j]
            ox=min(a.x1,b.x1)-max(a.x0,b.x0); oy=min(a.y1,b.y1)-max(a.y0,b.y0)
            if ox>0.04 and oy>0.04:
                ISSUES.append((pg,'SOLAPE',round(ox,2),(sa[:38]+' ⟂ '+sb[:38])))
    return _orig(self,fig,**kw)
PdfPages.savefig = audit_savefig
exec(open('build.py').read())
print("\n==== COLISIONES REALES ====")
for it in ISSUES: print(it)
print("TOTAL:", len(ISSUES))
